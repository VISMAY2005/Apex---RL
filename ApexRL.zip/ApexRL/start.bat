@echo off
setlocal
cd /d "%~dp0"
title ApexRL - race car reinforcement learning

set "PY="
python --version >nul 2>nul && set "PY=python"
if not defined PY py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY (
  echo.
  echo  Python 3.8 or newer was not found.
  echo  Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH".
  echo.
  pause
  exit /b 1
)

if not exist ".env" if exist ".env.example" copy ".env.example" ".env" >nul

echo Starting ApexRL... your browser will open on its own.
echo Close this window to stop it.
echo.
%PY% server.py
echo.
pause
