# Assets you can drop in here (all optional, PNG)

Missing files fall back to generated art, so nothing breaks. Hit Ctrl+F5 after adding files.
A white or solid background around sprites is removed automatically; transparent PNGs are best.

## Car, 3D chase view (rear of the car, camera behind it)
| File | What | Notes |
|---|---|---|
| `car_back.png` | rear view, day | about 600-1000 px wide; the shipped one is a placeholder |
| `car_back_lights.png` | rear view, tail lights ON | used at night and in rain; same size and framing as `car_back.png` |
| `car_back_left.png` | optional: car turning LEFT (rear + left side visible) | used when the car is angled left of the camera |
| `car_back_right.png` | optional: car turning RIGHT | used when angled right |

## Car, top-down view
`car.png` (day) and `car_lights.png` (night / rain), nose pointing LEFT (setting `CAR_IMG.facing` in `web/js/render.js`).

## Scenery
| File | What | Notes |
|---|---|---|
| `tree_1.png` ... `tree_4.png` | trees seen from the side, base of the trunk at the bottom edge | 256-512 px tall; pines and deciduous mix looks best; crop tightly |
| `sky_day.png` | wide sky panorama with clouds and a far tree line | about 2048x256 or 4096x512, left and right edges should join |
| `sky_night.png` | same, at night (stars, moon) | |
| `grass.png` | seamless grass tile | any square size, e.g. 512x512; used in BOTH views |
| `asphalt.png` | seamless asphalt tile | same; used in BOTH views |

Not wired yet (ask and I will add): textured tyre walls / guard rail, lamp post sprite, grandstands, signs, bridge.
