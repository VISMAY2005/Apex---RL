// Optional: trains with no browser. Usage:  node tools/headless_test.js [minutes] [nord|glb|practice] [imitate] [night] [rain]
const fs = require('fs'), path = require('path');
const code = ['nordschleife', '../data/nord_glb', 'env', 'track', 'sim', 'rl', 'trainer', 'human', 'drivers'].map(f => fs.readFileSync(path.join(__dirname, '..', 'web', 'js', f + '.js'), 'utf8')).join('\n');
const minutes = parseFloat(process.argv[2] || '1'), kind = process.argv[3] || 'nord', flags = process.argv.slice(4);
new Function(code + `
(async () => {
const T = new Trainer('${kind}'); const flags = ${JSON.stringify(flags)};
if (flags.includes('night')) T.env.dayMode = 'night'; if (flags.includes('rain')) T.env.weatherMode = 'rain'; T.env.snap();
console.log('lap km', (T.tr.lapLen/PXM/1000).toFixed(2), 'env', T.env.key());
const ex = new Expert(T.tr, 1); console.log('teacher ideal lap (s):', ex.lapTime().toFixed(0));
if (flags.includes('imitate')) { const t0 = Date.now(); await imitate(T, 1, () => {}); console.log('imitation done in', ((Date.now()-t0)/1000).toFixed(1)+'s'); }
const t0 = Date.now(); let lastU = -1;
while ((Date.now() - t0) < ${minutes} * 60000) {
  for (let i = 0; i < 500; i++) T.tick();
  if (T.stats.updates !== lastU && T.stats.updates % 20 === 0) {
    lastU = T.stats.updates; const s = T.stats;
    console.log(((Date.now()-t0)/1000).toFixed(0)+'s', 'attempts', s.attempts, 'avg10 m', T.avgRecent(10).toFixed(0), 'best m', s.bestM.toFixed(0), 'furthest km', (s.maxReach/PXM/1000).toFixed(2), 'laps', s.laps, 'bestLap', s.bestLap);
  }
  T.events.length = 0;
}
})();
`)();
