// Tests the "drive it yourself" pipeline with no browser. A scripted "human" presses the SAME keys a person would
// (arrows + space) so keyboard smoothing, recording, trimming, behaviour cloning and the test drive are all exercised.
// Usage: node tools/headless_demo_test.js [seconds of driving] [glb|nord|practice] [pace 0.3-1]
const fs = require('fs'), path = require('path');
const code = ['nordschleife', '../data/nord_glb', 'env', 'track', 'sim', 'rl', 'trainer', 'human', 'drivers'].map(f => fs.readFileSync(path.join(__dirname, '..', 'web', 'js', f + '.js'), 'utf8')).join('\n');
const secs = parseFloat(process.argv[2] || '240'), kind = process.argv[3] || 'glb', pace = parseFloat(process.argv[4] || '0.6');
new Function(code + `
(async () => {
const T = new Trainer('${kind}'); T.restartAtLine = false;
const ex = new Expert(T.tr, ${pace});
const before = T.evalPolicy(); console.log('untrained test drive: ' + Math.round(before.frac * 100) + '% of the lap');
T.setManual(true);
let steps = 0, hbPresses = 0;
const K = T.keys;
while (steps < ${secs} * 30) {
  const a = ex.act(T.car);                           // what a good human would want to do ...
  const want = { ArrowLeft: a[0] < -0.12, ArrowRight: a[0] > 0.12, ArrowUp: a[1] > 0.15, ArrowDown: a[1] < -0.35, Space: a[1] < -0.9 && T.car.v > 90 };
  for (const k in want) K.press(k, want[k]);         // ... pressed as real key events
  if (want.Space) hbPresses++;
  T.tick(); steps++; T.events.length = 0;
}
T.flushDemo();
const ph = '${kind}' === 'glb' ? 'real' : 'game';
console.log('driven: ' + (steps / 30) + ' s, runs ' + T.demo.runs.length + ', frames kept ' + T.demo.frames(ph) + ', km ' + (T.demo.meters(ph) / 1000).toFixed(2) + ', laps ' + T.demo.laps(ph) + ', handbrake ticks ' + hbPresses);
// save / load round trip
const j = T.demo.unsaved(); const D2 = new DemoStore(); D2.replaceWith(JSON.parse(JSON.stringify(j)));
console.log('save/load round trip: runs ' + j.length + ' -> ' + D2.runs.length + ', frames ' + D2.frames(ph), 'JSON size ' + (JSON.stringify(j).length / 1e6).toFixed(2) + ' MB');
T.setManual(false);
const t0 = Date.now(); const r = await learnFromDemos(T, 8, () => {});
console.log('learned from demos in ' + ((Date.now() - t0) / 1000).toFixed(1) + 's, test drive: ' + Math.round(r.test.frac * 100) + '% of the lap' + (r.test.lap ? ' (FULL LAP ' + r.test.t.toFixed(0) + ' s)' : ''));
// then a bit of normal RL with the anchor on
const t1 = Date.now(); let n = 0;
while (Date.now() - t1 < 1000) { for (let i = 0; i < 500; i++) T.tick(); T.events.length = 0; n += 500; }
console.log('after ' + Math.round(n / 30) + ' sim-seconds of RL with anchor: test drive ' + Math.round(T.lastEval.frac * 100) + '%, champion ' + Math.round(T.champ[T.env.key()].frac * 100) + '%, updates ' + T.stats.updates);
})();
`)();
