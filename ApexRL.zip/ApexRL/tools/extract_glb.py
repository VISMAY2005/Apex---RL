"""Extract a driving-track description from the Nurburgring GLB.

Output (web/data/nord_glb.json): centreline (x,z,y metres), road half-widths, wall distances left/right.
Needs numpy + scipy (only for this one-off step; the game itself needs nothing extra).
"""
import sys, re, json, struct
import numpy as np
from scipy.spatial import cKDTree
from scipy.ndimage import gaussian_filter1d

GLB = sys.argv[1]; GPS_JS = sys.argv[2]; OUT = sys.argv[3]
f = open(GLB, 'rb').read()
jl = struct.unpack('<I', f[12:16])[0]
j = json.loads(f[20:20 + jl]); binoff = 20 + jl + 8

def acc(i):
    a = j['accessors'][i]; bv = j['bufferViews'][a['bufferView']]
    o = binoff + bv.get('byteOffset', 0) + a.get('byteOffset', 0)
    nc = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3}[a['type']]
    dt = {5126: '<f4', 5125: '<u4', 5123: '<u2'}[a['componentType']]
    x = np.frombuffer(f, dtype=dt, count=a['count'] * nc, offset=o)
    return x.reshape(-1, nc) if nc > 1 else x

def mesh(mi):
    p = j['meshes'][mi]['primitives'][0]
    P = acc(p['attributes']['POSITION']).astype(np.float64); I = acc(p['indices']).reshape(-1, 3)
    return np.stack([P[:, 0], P[:, 2], -P[:, 1]], 1), I      # node matrix: x, z, -y  (y is up)

def tris(mi):
    W, I = mesh(mi); a, b, c = W[I[:, 0]], W[I[:, 1]], W[I[:, 2]]
    n = np.cross(b - a, c - a); ar = np.linalg.norm(n, axis=1) / 2; n /= np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    return a, b, c, n, ar

# ---------- road surface (mesh 1, upward facing) ----------
a, b, c, n, ar = tris(1)
up = n[:, 1] > 0.9
RA, RB, RC = a[up], b[up], c[up]
road_cen = (RA + RB + RC) / 3
rtree = cKDTree(road_cen[:, [0, 2]])

# ---------- raster of the road at 1 m ----------
X0, Z0 = np.floor(road_cen[:, 0].min() - 40), np.floor(road_cen[:, 2].min() - 40)
X1, Z1 = np.ceil(road_cen[:, 0].max() + 40), np.ceil(road_cen[:, 2].max() + 40)
RES = 1.0
GW, GH = int((X1 - X0) / RES) + 1, int((Z1 - Z0) / RES) + 1
from skimage.draw import polygon
mask = np.zeros((GH, GW), np.uint8)
hmap = np.full((GH, GW), np.nan, np.float32)
for A, B, C in zip(RA, RB, RC):
    xs = np.array([A[0], B[0], C[0]]); zs = np.array([A[2], B[2], C[2]])
    rr, cc = polygon((zs - Z0) / RES, (xs - X0) / RES, mask.shape)
    if len(rr): mask[rr, cc] = 1; hmap[rr, cc] = (A[1] + B[1] + C[1]) / 3
print('road raster', mask.shape, 'road cells', int(mask.sum()))
from scipy.ndimage import binary_closing, distance_transform_edt
mask = binary_closing(mask, iterations=2).astype(np.uint8)

# ---------- guide: existing GPS centreline registered to the GLB ----------
G = np.array(json.loads(re.search(r'=\s*(\[.*\])', open(GPS_JS).read(), re.S).group(1)))
seg = np.hypot(*np.diff(G, axis=0).T); cum = np.r_[0, np.cumsum(seg)]
t = np.arange(0, cum[-1], 6.0); P = np.stack([np.interp(t, cum, G[:, 0]), np.interp(t, cum, G[:, 1])], 1)
Q = P - P.mean(0) + road_cen[:, [0, 2]].mean(0)
for it in range(60):
    d, idx = rtree.query(Q); tgt = road_cen[idx][:, [0, 2]]
    mq, mt = Q.mean(0), tgt.mean(0); qq, tt = Q - mq, tgt - mt
    U, S, Vt = np.linalg.svd(qq.T @ tt); R = Vt.T @ U.T
    if np.linalg.det(R) < 0: Vt[-1] *= -1; R = Vt.T @ U.T
    Q = (qq @ R.T) * (S.sum() / (qq ** 2).sum()) + mt
print('registration median error m', np.median(rtree.query(Q)[0]).round(2))

# ---------- snap guide to the road centre by perpendicular scans ----------
def resample(Pc, step):
    Pc = np.vstack([Pc, Pc[:1]]); s = np.hypot(*np.diff(Pc, axis=0).T); cs = np.r_[0, np.cumsum(s)]
    tt = np.arange(0, cs[-1], step)
    return np.stack([np.interp(tt, cs, Pc[:, 0]), np.interp(tt, cs, Pc[:, 1])], 1), cs[-1]

def sm(Pc, sig):
    return np.stack([gaussian_filter1d(Pc[:, 0], sig, mode='wrap'), gaussian_filter1d(Pc[:, 1], sig, mode='wrap')], 1)

C, _ = resample(sm(Q, 2), 2.5)
offs = np.arange(-30, 30.01, 0.5)
def scan(C):
    M = len(C); tg = np.roll(C, -1, 0) - np.roll(C, 1, 0); tg /= np.linalg.norm(tg, axis=1, keepdims=True)
    nr = np.stack([-tg[:, 1], tg[:, 0]], 1)                      # left-hand normal in (x,z)
    px = C[:, 0:1] + nr[:, 0:1] * offs[None]; pz = C[:, 1:2] + nr[:, 1:2] * offs[None]
    gx = np.clip(((px - X0) / RES).astype(int), 0, GW - 1); gz = np.clip(((pz - Z0) / RES).astype(int), 0, GH - 1)
    on = mask[gz, gx] > 0
    lo = np.full(M, np.nan); hi = np.full(M, np.nan); mid0 = len(offs) // 2
    for i in range(M):
        row = on[i]
        if not row.any(): continue
        k = mid0 if row[mid0] else np.argmin(np.where(row, np.abs(np.arange(len(offs)) - mid0), 1e9))
        l = k
        while l > 0 and row[l - 1]: l -= 1
        h = k
        while h < len(offs) - 1 and row[h + 1]: h += 1
        lo[i], hi[i] = offs[l], offs[h]
    return nr, lo, hi
for it in range(6):
    nr, lo, hi = scan(C)
    mid = (lo + hi) / 2; mid = np.where(np.isnan(mid), 0, mid)
    mid = gaussian_filter1d(mid, 3, mode='wrap')
    C = C + nr * mid[:, None]
    C, L = resample(sm(C, 2.0), 2.5)
nr, lo, hi = scan(C)
M = len(C); print('centreline points', M, 'length m', round(L, 1))
bad = np.isnan(lo).sum(); print('points with no road found', bad)
def fill(x):
    x = x.copy(); ok = ~np.isnan(x); idx = np.arange(len(x)); x[~ok] = np.interp(idx[~ok], idx[ok], x[ok], period=len(x)); return x
lo, hi = fill(lo), fill(hi)
roadL = gaussian_filter1d(np.clip(hi, 1, 40), 2, mode='wrap'); roadR = gaussian_filter1d(np.clip(-lo, 1, 40), 2, mode='wrap')
print('road half-width left/right median', np.median(roadL).round(2), np.median(roadR).round(2), 'min', (roadL + roadR).min().round(1), 'max', (roadL + roadR).max().round(1))

# elevation along the centreline
ytree_d, ytree_i = rtree.query(C, k=6)
elev = road_cen[ytree_i][:, :, 1].mean(1); elev = gaussian_filter1d(elev, 3, mode='wrap')
print('elevation range', elev.min().round(1), elev.max().round(1))

# ---------- walls: vertical faces of meshes 0 and 2 (about 1 m tall, hugging the road) ----------
wp = []
for mi in (0, 2):
    a, b, c, n, ar = tris(mi); v = np.abs(n[:, 1]) < 0.4
    a, b, c = a[v], b[v], c[v]
    for u in (0.0, 0.5, 1.0):
        for w in (0.0, 0.5, 1.0):
            if u + w <= 1: wp.append(a + (b - a) * u + (c - a) * w)
    wp.append((a + b) / 2); wp.append((b + c) / 2); wp.append((a + c) / 2)
wp = np.vstack(wp)
ctree = cKDTree(C)
d, ci = ctree.query(wp[:, [0, 2]])
ok = d < 40
wp, ci, d = wp[ok], ci[ok], d[ok]
tg = np.roll(C, -1, 0) - np.roll(C, 1, 0); tg /= np.linalg.norm(tg, axis=1, keepdims=True); nrm = np.stack([-tg[:, 1], tg[:, 0]], 1)
lat = (wp[:, 0] - C[ci, 0]) * nrm[ci, 0] + (wp[:, 2] - C[ci, 1]) * nrm[ci, 1]
# wall must be at or beyond the road edge (give 1.5 m slack) and above the road surface
WL = np.full(M, np.nan); WR = np.full(M, np.nan)
for i in range(M):
    pass
order = np.argsort(ci)
ci_s, lat_s = ci[order], lat[order]
starts = np.searchsorted(ci_s, np.arange(M + 1))
WIN = 3
for i in range(M):
    idxs = [(i + k) % M for k in range(-WIN, WIN + 1)]
    vals = np.concatenate([lat_s[starts[k]:starts[k + 1]] for k in idxs])
    left = vals[vals > roadL[i] - 1.5]; right = vals[vals < -roadR[i] + 1.5]
    if len(left): WL[i] = left.min()
    if len(right): WR[i] = -right.max()
capL = 14.0
covL = np.mean(~np.isnan(WL)); covR = np.mean(~np.isnan(WR))
print('wall found on left %.0f%% right %.0f%% of centreline samples' % (100 * covL, 100 * covR))
print('wall offset beyond road edge  left median', np.nanmedian(WL - roadL).round(2), ' right', np.nanmedian(WR - roadR).round(2))

# ---------- clean-up and output ----------
from scipy.ndimage import median_filter
roadL = np.clip(median_filter(roadL, 25, mode='wrap'), 3.0, 6.5)       # junctions / pit lane make the raw width jump
roadR = np.clip(median_filter(roadR, 25, mode='wrap'), 3.0, 6.5)
def fill_gaps(w, maxgap):
    """w: NaN where no wall. Bridge short gaps (a wall with a gap in the mesh is still a wall) and drop tiny fragments."""
    ok = ~np.isnan(w); n = len(w); out = w.copy()
    i = 0
    while i < n:
        if not ok[i]:
            j = i
            while j < n and not ok[j]: j += 1
            if j - i <= maxgap and i > 0 and j < n:
                out[i:j] = np.interp(np.arange(i, j), [i - 1, j], [w[i - 1], w[j]])
            i = j
        else: i += 1
    ok = ~np.isnan(out); i = 0
    while i < n:                                                   # fragments shorter than 6 samples (15 m) are noise
        if ok[i]:
            j = i
            while j < n and ok[j]: j += 1
            if j - i < 6: out[i:j] = np.nan
            i = j
        else: i += 1
    return out
WL = fill_gaps(WL, 8); WR = fill_gaps(WR, 8)
OPEN = 4.0       # no wall on this side: the road is bordered by an open grass strip this wide, then a hard edge (bank / trees)
hasL = ~np.isnan(WL); hasR = ~np.isnan(WR)
bndL = np.where(hasL, np.maximum(WL, roadL + 0.8), roadL + OPEN); bndR = np.where(hasR, np.maximum(WR, roadR + 0.8), roadR + OPEN)
bndL = np.minimum(bndL, roadL + 10); bndR = np.minimum(bndR, roadR + 10)
print('after clean-up: walls left %.0f%% right %.0f%%; road width median %.1f m; corridor width median %.1f m' % (100*hasL.mean(), 100*hasR.mean(), np.median(roadL+roadR), np.median(bndL+bndR)))
r1 = lambda a: [round(float(v), 1) for v in a]
out = dict(M=int(M), step=round(L / M, 4), lapLen=round(float(L), 1),
           x=r1(C[:, 0]), z=r1(C[:, 1]), y=r1(elev), roadL=r1(roadL), roadR=r1(roadR), bndL=r1(bndL), bndR=r1(bndR),
           wallL=[int(v) for v in hasL], wallR=[int(v) for v in hasR])
import os
os.makedirs(os.path.dirname(OUT), exist_ok=True)
open(OUT, 'w').write('/* Generated by tools/extract_glb.py from the Nurburgring GLB (see README). Metres; x/z = ground plane, y = height. */\nconst NORD_GLB = ' + json.dumps(out, separators=(',', ':')) + ';\n')
print('wrote', OUT, os.path.getsize(OUT) // 1024, 'KB')
