"""ApexRL local server. Standard library only - nothing to pip install.

Serves the web/ folder, saves/loads the trained brain, and proxies the optional LLM "coach"
so your API key stays on your machine (never sent to the browser).
"""
import json, os, re, sys, threading, urllib.parse, urllib.request, urllib.error, webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(ROOT, "web")
SAVES = os.path.join(ROOT, "saves")
os.makedirs(SAVES, exist_ok=True)


def load_env():
    path = os.path.join(ROOT, ".env")
    if not os.path.exists(path):
        return
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_env()
PORT = int(os.environ.get("PORT", "8765"))

SYSTEM = (
    "You are a reinforcement-learning coach for a 2D top-down race car learning the Nurburgring Nordschleife with PPO. "
    "The car sees only 9 distance sensors plus its speed and steering angle. Reward per step = "
    "wProg*progress_px + wSpeed*speed - wCenter*(offset/halfwidth)^2 - wSafe*(speed too high to stop within the road the centre sensors see), and a one-off penalty 'crash' when it hits a barrier. "
    "Conditions can be Day/Night and Dry/Rain: night shortens and blurs the sensors, rain cuts grip so the car slides, so lower scores in those conditions are expected and not a reason to panic. "
    "Given training stats (distances are in metres per attempt) and current hyper-parameters, suggest small adjustments (at most about 2x change per value). "
    "Allowed keys and ranges: lr [1e-4,2e-3], entropy [0,0.02], wProg [0.01,0.2], wSpeed [0,0.08], wCenter [0,0.3], wSafe [0,1.5], crash [1,15]. "
    "Heuristics: very short attempts -> more exploration (entropy) or a larger crash penalty; "
    "attempts mostly reaching the lap length and lap times plateauing -> lower entropy and lr, raise wSpeed; "
    "weaving -> raise wCenter; progress stuck at the same corner -> keep exploration up. Reply with ONLY a JSON object: "
    '{"explanation": "<two short sentences>", "changes": {"key": number, ...}}.'
)


def http_json(url, headers, body):
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json", **headers})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"{e.code} from provider: {e.read().decode(errors='replace')[:300]}")


def ask_llm(payload):
    keys = {"gemini": os.environ.get("GEMINI_API_KEY"), "groq": os.environ.get("GROQ_API_KEY")}
    prefer = os.environ.get("COACH_PROVIDER", "auto").lower()
    provider = prefer if keys.get(prefer) else next((p for p, k in keys.items() if k), None)
    if provider is None:
        return None, None
    user = "Training stats and current settings:\n" + json.dumps(payload)
    if provider == "groq":
        model = os.environ.get("GROQ_MODEL", "openai/gpt-oss-120b")
        out = http_json("https://api.groq.com/openai/v1/chat/completions", {"Authorization": "Bearer " + keys[provider]},
                        {"model": model, "max_completion_tokens": 2000,
                         "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}]})
        text = out["choices"][0]["message"].get("content") or ""
    else:
        model = os.environ.get("GEMINI_MODEL", "gemini-flash-latest")
        out = http_json(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent", {"x-goog-api-key": keys[provider]},
                        {"systemInstruction": {"parts": [{"text": SYSTEM}]}, "contents": [{"role": "user", "parts": [{"text": user}]}],
                         "generationConfig": {"maxOutputTokens": 2000, "responseMimeType": "application/json"}})
        text = "".join(p.get("text", "") for p in out["candidates"][0]["content"]["parts"])
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise RuntimeError("Coach did not return JSON: " + text[:200])
    return f"{provider} / {model}", json.loads(m.group(0))


def rule_coach(p):
    s, hp, ch, why = p["stats"], p["hp"], {}, []
    lap_m = s.get("lapKm", 1) * 1000
    avg = s.get("avgRecentMeters", 0)
    if avg > 0.6 * lap_m:
        ch["entropy"] = hp["entropy"] * 0.6; ch["lr"] = hp["lr"] * 0.8; ch["wSpeed"] = hp["wSpeed"] * 1.5
        why.append("Most attempts nearly finish a lap, so I reduce exploration and nudge the reward towards speed.")
    elif avg < 0.1 * lap_m:
        ch["entropy"] = hp["entropy"] * 1.4; ch["crash"] = hp["crash"] + 1
        why.append("Attempts are still short, so I raise exploration and make crashes costlier.")
    else:
        ch["wCenter"] = hp["wCenter"] * 1.3
        why.append("Progress is partial; rewarding lane position should reduce clipped barriers.")
    return "local rule-based coach", {"explanation": " ".join(why), "changes": ch}


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **k):
        super().__init__(*a, directory=WEB, **k)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, *a):
        pass

    def translate_path(self, path):
        # /assets/... is served from the top-level assets/ folder (where you drop car.png) - and nothing outside it
        clean = path.split("?", 1)[0].split("#", 1)[0]
        if clean.startswith("/assets/"):
            base = os.path.realpath(os.path.join(ROOT, "assets"))
            target = os.path.realpath(os.path.join(base, urllib.parse.unquote(clean[len("/assets/"):])))
            return target if target == base or target.startswith(base + os.sep) else os.path.join(base, "__blocked__")
        return super().translate_path(path)

    def _send(self, code, obj):
        data = json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

    def _body(self):
        return json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")

    def do_GET(self):
        if self.path == "/api/assets":
            d = os.path.join(ROOT, "assets")
            return self._send(200, sorted(f for f in os.listdir(d) if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))) if os.path.isdir(d) else [])
        if self.path == "/api/demos/load":
            f = os.path.join(SAVES, "demos.json")
            if not os.path.exists(f):
                return self._send(404, {"error": "no saved laps"})
            return self._send(200, json.load(open(f, encoding="utf-8")))
        if self.path == "/api/load":
            f = os.path.join(SAVES, "brain.json")
            if not os.path.exists(f):
                return self._send(404, {"error": "no saved brain"})
            return self._send(200, json.load(open(f, encoding="utf-8")))
        return super().do_GET()

    def do_POST(self):
        try:
            if self.path == "/api/save":
                json.dump(self._body(), open(os.path.join(SAVES, "brain.json"), "w", encoding="utf-8"))
                return self._send(200, {"ok": True})
            if self.path == "/api/demos/save":
                # your recorded laps are APPENDED to saves/demos.json, so several sessions add up (delete the file to start over)
                f = os.path.join(SAVES, "demos.json")
                old = json.load(open(f, encoding="utf-8")) if os.path.exists(f) else {"v": 1, "runs": []}
                new = self._body().get("runs", [])
                old["runs"].extend(new)
                json.dump(old, open(f, "w", encoding="utf-8"), separators=(",", ":"))
                return self._send(200, {"ok": True, "added": len(new), "total": len(old["runs"])})
            if self.path == "/api/coach":
                payload = self._body()
                try:
                    provider, res = ask_llm(payload)
                    if provider is None:
                        provider, res = rule_coach(payload)
                except Exception as e:   # provider problem -> fall back so training never blocks
                    provider, res = rule_coach(payload)
                    res["explanation"] = f"(LLM call failed: {e}) " + res["explanation"]
                return self._send(200, {"provider": provider, **res})
        except Exception as e:
            return self._send(500, {"error": str(e)})
        self._send(404, {"error": "not found"})


if __name__ == "__main__":
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError:
        sys.exit(f"Port {PORT} is busy. Close the other ApexRL window or set PORT=9000 in .env")
    url = f"http://127.0.0.1:{PORT}"
    print(f"ApexRL running at {url}   (Ctrl+C to stop)")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
