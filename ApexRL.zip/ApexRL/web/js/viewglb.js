/* 3D chase view that renders the REAL Nürburgring GLB model (assets/nurburgring.glb) with three.js.
   The model is parsed here directly (no GLTFLoader needed): positions are rotated from the file's Z-up to Y-up and the ground plane
   (x, z) is the same plane the simulator drives in, so   metres X = (simX + tr.ox) / PXM,  metres Z = (simY + tr.oy) / PXM.
   The simulation itself never looks at this model: it uses the walls/road extracted from it (tools/extract_glb.py). */

const GLB_FILE = 'assets/nurburgring.glb';

class ViewGLB {
  constructor() {
    this.state = 'idle';            // idle | loading | ready | failed
    this.msg = ''; this.pct = 0; this.tr = null; this.res = 270; this.aspect = 16 / 9;
    this.camDist = 48; this.camH = 15; this.camYaw = null; this.lastX = 0; this.lastY = 0;
  }

  setRes(h, aspect) { this.res = h; this.aspect = aspect; if (this.R) this.R.setSize(Math.round(h * aspect), h, false); if (this.cam) { this.cam.aspect = aspect; this.cam.updateProjectionMatrix(); } }
  setTrack(tr) { this.tr = tr; this.camYaw = null; }

  async ensure() {
    if (this.state !== 'idle') return;
    this.state = 'loading'; this.msg = 'Loading the 3D Nürburgring...';
    try { await this.load(); this.state = 'ready'; }
    catch (e) { console.error(e); this.state = 'failed'; this.msg = e.message || String(e); }
  }

  async load() {
    const THREE = this.THREE = await import('../vendor/three.module.min.js');
    const resp = await fetch(GLB_FILE + '?v=' + Date.now());
    if (!resp.ok) throw new Error('assets/nurburgring.glb not found (copy the .glb into the assets folder)');
    const total = +resp.headers.get('Content-Length') || 14e6, rd = resp.body.getReader(), parts = []; let got = 0;
    for (;;) { const { done, value } = await rd.read(); if (done) break; parts.push(value); got += value.length; this.pct = Math.min(0.9, got / total); }
    const buf = new Uint8Array(got); let o = 0; for (const p of parts) { buf.set(p, o); o += p.length; }
    this.msg = 'Building the 3D world...';
    const dv = new DataView(buf.buffer), jl = dv.getUint32(12, true), J = JSON.parse(new TextDecoder().decode(buf.subarray(20, 20 + jl)));
    const bs = 20 + jl + 8, bin = buf.buffer.slice(bs, bs + dv.getUint32(20 + jl, true));
    const acc = i => {
      const a = J.accessors[i], bv = J.bufferViews[a.bufferView], off = (bv.byteOffset || 0) + (a.byteOffset || 0), n = { SCALAR: 1, VEC2: 2, VEC3: 3 }[a.type];
      return new (a.componentType === 5126 ? Float32Array : a.componentType === 5125 ? Uint32Array : Uint16Array)(bin, off, a.count * n);
    };
    // the one shared texture atlas
    const ib = J.bufferViews[J.images[0].bufferView];
    const bmp = await createImageBitmap(new Blob([new Uint8Array(bin, ib.byteOffset || 0, ib.byteLength)], { type: 'image/png' }), { imageOrientation: 'none' });
    const atlas = new THREE.Texture(bmp); atlas.flipY = false; atlas.wrapS = atlas.wrapT = THREE.RepeatWrapping; atlas.colorSpace = THREE.SRGBColorSpace; atlas.magFilter = THREE.NearestFilter; atlas.needsUpdate = true;
    // The model's road and fence strips use tiled UVs that don't survive its merged texture atlas, so those two get their own look.
    const asph = new THREE.CanvasTexture(noiseTile([66, 68, 76], 18, 9000, 384, 20)); asph.wrapS = asph.wrapT = THREE.RepeatWrapping; asph.colorSpace = THREE.SRGBColorSpace;
    this.mats = [];
    const mk = (opts) => { const m = new THREE.MeshBasicMaterial({ side: THREE.DoubleSide, ...opts }); m.userData.base = m.color.clone(); this.mats.push(m); return m; };
    const mAtlas = mk({ map: atlas }), mRoad = mk({ map: asph, vertexColors: true }), mRail = mk({ color: 0xb4b8c2 });

    this.world = new THREE.Group();
    J.meshes.forEach((mesh, mi) => {
      const p = mesh.primitives[0], pos = acc(p.attributes.POSITION), nor = acc(p.attributes.NORMAL), uv = acc(p.attributes.TEXCOORD_0), idx = acc(p.indices), n = pos.length / 3;
      const P = new Float32Array(pos.length), N = new Float32Array(pos.length);
      for (let i = 0; i < n; i++) {                                 // Z-up -> Y-up:  (x, y, z) -> (x, z, -y)
        P[3 * i] = pos[3 * i]; P[3 * i + 1] = pos[3 * i + 2]; P[3 * i + 2] = -pos[3 * i + 1];
        N[3 * i] = nor[3 * i]; N[3 * i + 1] = nor[3 * i + 2]; N[3 * i + 2] = -nor[3 * i + 1];
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(P, 3));
      let mat = mAtlas;
      if (mi === 1) {                                               // road: planar asphalt, darker on vertical faces (kerb sides)
        const U = new Float32Array(2 * n), C = new Float32Array(3 * n);
        for (let i = 0; i < n; i++) { U[2 * i] = P[3 * i] / 11; U[2 * i + 1] = P[3 * i + 2] / 11; const up = N[3 * i + 1] > 0.7; C[3 * i] = up ? 1 : 0.62; C[3 * i + 1] = up ? 1 : 0.5; C[3 * i + 2] = up ? 1 : 0.5; }
        geo.setAttribute('uv', new THREE.BufferAttribute(U, 2)); geo.setAttribute('color', new THREE.BufferAttribute(C, 3)); mat = mRoad;
      } else if (mi === 2) mat = mRail;
      else geo.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(uv), 2));
      geo.setIndex(new THREE.BufferAttribute(idx, 1));
      geo.computeBoundingSphere();
      const m = new THREE.Mesh(geo, mat); m.frustumCulled = true; this.world.add(m);
    });

    // renderer, scene, camera
    this.R = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
    this.R.setSize(Math.round(this.res * this.aspect), this.res, false);
    this.scene = new THREE.Scene(); this.scene.fog = new THREE.FogExp2(0x9fc4e8, 0.0016); this.scene.background = new THREE.Color(0x9fc4e8);
    this.scene.add(this.world);
    this.cam = new THREE.PerspectiveCamera(62, this.aspect, 0.4, 5000);
    const gm = this.groundMat = new THREE.MeshBasicMaterial({ color: 0x3c6a34 }); gm.userData.base = gm.color.clone(); this.mats.push(gm);
    this.ground = new THREE.Mesh(new THREE.PlaneGeometry(9000, 9000).rotateX(-Math.PI / 2), gm); this.scene.add(this.ground);   // hides the void beyond the model's terrain strip

    // car: a billboard (your rear-view PNG), a soft shadow, and the headlight pool
    const blob = document.createElement('canvas'); blob.width = blob.height = 64; { const x = blob.getContext('2d'), gr = x.createRadialGradient(32, 32, 2, 32, 32, 30); gr.addColorStop(0, 'rgba(0,0,0,.7)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = gr; x.fillRect(0, 0, 64, 64); }
    this.shadow = new THREE.Mesh(new THREE.PlaneGeometry(2.8, 5.4).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(blob), transparent: true, depthWrite: false })); this.scene.add(this.shadow);
    const cone = document.createElement('canvas'); cone.width = 128; cone.height = 256; { const x = cone.getContext('2d'), gr = x.createLinearGradient(0, 256, 0, 0); gr.addColorStop(0, 'rgba(255,240,190,.5)'); gr.addColorStop(1, 'rgba(255,244,200,0)'); x.fillStyle = gr; x.beginPath(); x.moveTo(52, 256); x.lineTo(76, 256); x.lineTo(128, 0); x.lineTo(0, 0); x.closePath(); x.fill(); }
    this.beam = new THREE.Mesh(new THREE.PlaneGeometry(20, 52).rotateX(-Math.PI / 2).translate(0, 0, -26), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(cone), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false })); this.beam.renderOrder = 1; this.scene.add(this.beam);   // headlight pool is drawn BEFORE the car so the car sits on top of it
    this.carDay = new THREE.Sprite(new THREE.SpriteMaterial({ transparent: true })); this.carLit = new THREE.Sprite(new THREE.SpriteMaterial({ transparent: true, opacity: 0 }));
    this.carDay.renderOrder = 2; this.carLit.renderOrder = 3;   // car always drawn after (over) the headlight beam
    for (const s of [this.carDay, this.carLit]) { s.center.set(0.5, 0.02); this.scene.add(s); }
    this.hasBack = false;
    // sensor rays
    this.rayGeo = new THREE.BufferGeometry(); this.rayGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(RAYS.length * 6), 3)); this.rayGeo.setAttribute('color', new THREE.BufferAttribute(new Float32Array(RAYS.length * 6), 3));
    this.rays = new THREE.LineSegments(this.rayGeo, new THREE.LineBasicMaterial({ vertexColors: true, depthTest: false, transparent: true })); this.rays.renderOrder = 10; this.rays.frustumCulled = false; this.scene.add(this.rays);
    this.sky = { day: new THREE.Color(0x9fc4e8), night: new THREE.Color(0x070b1c), rain: new THREE.Color(0x77818c) };
  }

  carSprites() {                                                 // use the user's rear-view PNGs once they have loaded; until then a simple rear view
    const THREE = this.THREE;
    const fallback = () => { const c = document.createElement('canvas'); c.width = 160; c.height = 100; const x = c.getContext('2d'); x.fillStyle = '#c8cdd6'; x.fillRect(14, 22, 132, 46); x.fillStyle = '#20242c'; x.fillRect(34, 8, 92, 24); x.fillStyle = '#e0252f'; x.fillRect(18, 44, 26, 9); x.fillRect(116, 44, 26, 9); x.fillStyle = '#111'; x.fillRect(8, 62, 26, 32); x.fillRect(126, 62, 26, 32); return c; };
    const a = art3d.back || fallback(), b = art3d.backLights || a;
    for (const [sp, cv] of [[this.carDay, a], [this.carLit, b]]) { const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; sp.material.map = t; sp.material.needsUpdate = true; sp.userData.aspect = cv.width / cv.height; }
    this.hasBack = !!art3d.back;
  }

  // o: { car: {x, y, h, v, vang}, idx, dt, mix, showRays, rays: car }
  render(o) {
    const THREE = this.THREE, tr = this.tr, c = o.car, PXMm = PXM, ENVn = ENV.night, wet = Math.max(ENV.rain, ENV.wet * 0.6);
    if (!this.carDay.material.map || (!this.hasBack && art3d.back)) this.carSprites();
    const toX = x => (x + tr.ox) / PXMm, toZ = y => (y + tr.oy) / PXMm;
    const f = o.idx, elev = tr.elev[f];
    const X = toX(c.x), Z = toZ(c.y), Y = elev;
    // chase camera: yaw follows a blend of where the car points and where it is travelling, with some lag
    const want = Math.atan2(Math.sin(c.h) * 0.6 + Math.sin(c.vang) * 0.4, Math.cos(c.h) * 0.6 + Math.cos(c.vang) * 0.4);
    if (this.camYaw === null || Math.hypot(c.x - this.lastX, c.y - this.lastY) > 120) this.camYaw = want;
    this.lastX = c.x; this.lastY = c.y;
    let d = want - this.camYaw; d = Math.atan2(Math.sin(d), Math.cos(d)); this.camYaw += d * Math.min(1, 6 * (o.dt || 0.016));
    const dist = this.camDist / 48 * 9.5, hgt = this.camH / 15 * 3.4, dirX = Math.cos(this.camYaw), dirZ = Math.sin(this.camYaw);
    const ci = (f - Math.round(dist / (tr.spacing / PXMm)) + tr.M) % tr.M;                    // camera must not sink into the road behind a crest
    const camY = Math.max(Y, tr.elev[ci]) + hgt;
    this.cam.position.set(X - dirX * dist, camY, Z - dirZ * dist);
    this.cam.lookAt(X + dirX * 9, Y + 1.1, Z + dirZ * 9);
    const fov = 58 + 16 * Math.min(1, c.v / MAXV); if (Math.abs(fov - this.cam.fov) > 0.05) { this.cam.fov = fov; this.cam.updateProjectionMatrix(); }

    // car + shadow + headlight pool
    const heading = -c.h + Math.PI / 2;
    for (const sp of [this.carDay, this.carLit]) { const asp = sp.userData.aspect || 1.6; sp.scale.set(2.3 * 1.15, 2.3 * 1.15 / asp, 1); sp.position.set(X, Y, Z); }
    const lights = o.mix; this.carDay.material.opacity = 1; this.carLit.material.opacity = lights; this.carLit.visible = lights > 0.02; this.carDay.visible = true;   // day sprite stays solid underneath so the beam never shows through the car
    this.shadow.position.set(X, Y + 0.06, Z); this.shadow.rotation.y = heading;
    this.beam.position.set(X + Math.cos(c.h) * 2.4, Y + 0.08, Z + Math.sin(c.h) * 2.4); this.beam.rotation.y = heading; this.beam.visible = lights > 0.02; this.beam.material.opacity = lights * (1 - 0.5 * ENV.rain) * 0.55;
    this.ground.position.set(X, Y - 3.5, Z);

    // conditions: night darkens everything, rain greys and thickens the fog
    const dayK = 1 - ENVn, k = (0.2 + 0.8 * dayK) * (1 - 0.18 * ENV.rain), tint = (r, g, b) => [r * k, g * k, b * (k + 0.06 * ENVn)];
    for (const m of this.mats) { const b0 = m.userData.base, t = tint(b0.r, b0.g, b0.b); m.color.setRGB(t[0] * (1 - 0.1 * wet), t[1] * (1 - 0.1 * wet), t[2] * (1 - 0.1 * wet)); }
    const sky = this.scene.background; sky.copy(this.sky.day).lerp(this.sky.rain, ENV.rain * 0.85).lerp(this.sky.night, ENVn); this.scene.fog.color.copy(sky);
    this.scene.fog.density = 0.0015 + 0.0042 * ENV.rain + 0.0012 * ENVn;

    // sensor rays (only the car's 9 bumper rays, exactly what the AI reads)
    this.rays.visible = !!o.showRays;
    if (o.showRays) {
      const r = o.rays, P = this.rayGeo.attributes.position.array, Cc = this.rayGeo.attributes.color.array;
      for (let i = 0; i < RAYS.length; i++) {
        const sy = tr.elev[f] + 0.7, v = r.reading[i], col = new THREE.Color().setHSL(v * 0.33, 0.95, 0.55);
        P.set([toX(r.ox), sy, toZ(r.oy), toX(r.hx[i]), sy, toZ(r.hy[i])], i * 6); Cc.set([col.r, col.g, col.b, col.r, col.g, col.b], i * 6);
      }
      this.rayGeo.attributes.position.needsUpdate = true; this.rayGeo.attributes.color.needsUpdate = true;
    }
    this.R.render(this.scene, this.cam);
    return this.R.domElement;
  }
}
