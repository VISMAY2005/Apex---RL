/* Environment: time of day + weather. ENV holds the live values (0..1) that physics, sensors, lights and rain all read. */
const ENV = { night: 0, rain: 0, wet: 0 };
const STAGES = [['day', 'sunny'], ['night', 'sunny'], ['day', 'rain'], ['night', 'rain']];   // curriculum: easy -> hard
const DAY_SIM_SECONDS = 720;                                                                // one 24 h cycle = 12 simulated minutes

class EnvCtl {
  constructor() { this.dayMode = 'day'; this.weatherMode = 'sunny'; this.tod = 10; this.raining = false; this.timer = 150; this.intensity = 1; this.snap(); }

  targets() {
    const s = Math.sin((this.tod - 6) / 24 * 2 * Math.PI);                       // noon = 1, midnight = -1
    const tn = this.dayMode === 'night' ? 1 : this.dayMode === 'auto' ? clamp((0.25 - s) / 0.5, 0, 1) : 0;
    const tr = this.weatherMode === 'rain' ? 1 : this.weatherMode === 'random' ? (this.raining ? this.intensity : 0) : 0;
    return [tn, tr];
  }
  snap() { const [n, r] = this.targets(); ENV.night = n; ENV.rain = r; ENV.wet = r; }

  update(dt) {
    if (this.dayMode === 'auto') this.tod = (this.tod + dt / DAY_SIM_SECONDS * 24) % 24;
    if (this.weatherMode === 'random') {
      this.timer -= dt;
      if (this.timer <= 0) {
        this.raining = !this.raining; this.intensity = 0.6 + Math.random() * 0.4;
        this.timer = this.raining ? 60 + Math.random() * 100 : 100 + Math.random() * 260;
      }
    }
    const [tn, tr] = this.targets();
    ENV.night += (tn - ENV.night) * Math.min(1, dt / 4);
    ENV.rain += (tr - ENV.rain) * Math.min(1, dt / 4);
    ENV.wet += (ENV.rain - ENV.wet) * Math.min(1, dt / (ENV.rain > ENV.wet ? 6 : 50));   // track dries slowly
  }

  key() { return (ENV.night > 0.5 ? 'Night' : 'Day') + ' / ' + (ENV.wet > 0.3 ? 'Rain' : 'Dry'); }
  clock() { const h = Math.floor(this.tod), m = Math.floor((this.tod - h) * 60); return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0'); }
}
