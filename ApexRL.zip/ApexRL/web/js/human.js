/* Human driving: keyboard controls, a recorder for your laps ("demonstrations"), and learning from them (behaviour cloning).
   The recorder stores exactly what the AI would see (the 14 sensor numbers) and what you did with the wheel and pedals,
   so the network can learn "in a situation like this, the human did that" - and not waste time exploring wrong paths. */

/* ---------- keyboard ---------- */
// Arrow Up = throttle, Arrow Down = brake, Left/Right = steer, Space = handbrake. Values are smoothed so a key press is not an instant 100%.
class HumanInput {
  constructor() { this.down = new Set(); this.s = 0; this.th = 0; this.hb = 0; }
  press(code, isDown) { if (isDown) this.down.add(code); else this.down.delete(code); }
  clear() { this.down.clear(); this.s = 0; this.th = 0; this.hb = 0; }
  static isDriveKey(code) { return code === 'ArrowUp' || code === 'ArrowDown' || code === 'ArrowLeft' || code === 'ArrowRight' || code === 'Space'; }

  // Called once per physics step (30 per second). v = current speed in px/s: steering gets gentler at speed so a key tap isn't a spin.
  read(v = 0) {
    const d = this.down, ts = (d.has('ArrowRight') ? 1 : 0) - (d.has('ArrowLeft') ? 1 : 0);
    const tt = d.has('ArrowUp') ? 1 : d.has('ArrowDown') ? -1 : 0;
    const base = 0.18 / (1 + v / 200), opposite = ts !== 0 && this.s !== 0 && Math.sign(ts) !== Math.sign(this.s);
    const rate = ts === 0 ? 0.3 : opposite ? base * 2.2 : base;                    // returns to centre faster than it turns in
    this.s += clamp(ts - this.s, -rate, rate);
    const tr = tt > this.th ? 0.2 : 0.4;                                            // lifting and braking are quicker than building throttle
    this.th += clamp(tt - this.th, -tr, tr);
    this.hb = d.has('Space') ? 1 : 0;
    return { s: this.s, th: this.th, hb: this.hb };
  }
}

/* ---------- recorded laps ---------- */
const DEMO_TRIM = 25;        // steps (about 0.8 s) before a crash are thrown away: they are the mistake, not the lesson
const DEMO_MIN = 45;         // runs shorter than this are not worth keeping

class DemoStore {
  constructor() { this.runs = []; this.savedUpTo = 0; this.begin(); }

  begin() { this.ep = { obs: [], act: [], r: [] }; }

  push(obs, act, r) { this.ep.obs.push(Float32Array.from(obs)); this.ep.act.push(act); this.ep.r.push(r); }

  // Close the current run. Returns what was kept.
  end(kind, gamma, phys, meters, fromLine) {
    const e = this.ep; this.begin();
    const n = e.obs.length; if (!n) return { kept: 0, dropped: 0 };
    const ret = new Float64Array(n); let R = 0;
    for (let i = n - 1; i >= 0; i--) { R = e.r[i] + gamma * R; ret[i] = R; }       // discounted return, crash penalty included
    const drop = (kind === 'crash' || kind === 'stall') ? Math.min(n, DEMO_TRIM) : 0, keep = n - drop;
    if (keep < DEMO_MIN) return { kept: 0, dropped: n };
    this.runs.push({
      phys, lap: kind === 'lap' && fromLine, m: Math.round(meters), n: keep,
      obs: e.obs.slice(0, keep), act: e.act.slice(0, keep), ret: Array.from(ret.slice(0, keep)),
    });
    return { kept: keep, dropped: drop };
  }

  discardCurrent() { this.begin(); }
  undoLast() { const r = this.runs.pop(); this.savedUpTo = Math.min(this.savedUpTo, this.runs.length); return r || null; }
  clear() { this.runs = []; this.savedUpTo = 0; this.begin(); }

  frames(phys) { let n = 0; for (const r of this.runs) if (!phys || r.phys === phys) n += r.n; return n; }
  meters(phys) { let m = 0; for (const r of this.runs) if (!phys || r.phys === phys) m += r.m; return m; }
  laps(phys) { let k = 0; for (const r of this.runs) if ((!phys || r.phys === phys) && r.lap) k++; return k; }

  // flat training set for the current physics ('real' or 'game')
  dataset(phys) {
    const obs = [], act = [], ret = [];
    for (const r of this.runs) if (r.phys === phys) for (let i = 0; i < r.n; i++) { obs.push(r.obs[i]); act.push(r.act[i]); ret.push(r.ret[i]); }
    return { obs, act, ret, n: obs.length };
  }

  runToJSON(r) {
    const q = x => Math.round(x * 1000) / 1000, obs = [], act = [];
    for (let i = 0; i < r.n; i++) { for (let k = 0; k < r.obs[i].length; k++) obs.push(q(r.obs[i][k])); act.push(q(r.act[i][0]), q(r.act[i][1])); }
    return { phys: r.phys, lap: r.lap, m: r.m, n: r.n, nin: NIN, obs, act, ret: r.ret.map(q) };
  }
  runFromJSON(j) {
    if (j.nin !== NIN) throw new Error('Saved laps use a different sensor layout.');
    const obs = [], act = [];
    for (let i = 0; i < j.n; i++) { obs.push(Float32Array.from(j.obs.slice(i * NIN, (i + 1) * NIN))); act.push([j.act[2 * i], j.act[2 * i + 1]]); }
    return { phys: j.phys, lap: !!j.lap, m: j.m, n: j.n, obs, act, ret: j.ret };
  }
  unsaved() { return this.runs.slice(this.savedUpTo).map(r => this.runToJSON(r)); }
  replaceWith(list) { this.runs = list.map(j => this.runFromJSON(j)); this.savedUpTo = this.runs.length; this.begin(); }
}

/* ---------- learning from the recorded laps ---------- */

// One small supervised step on random recorded samples (used to keep the AI anchored to your driving while RL runs).
function bcStep(agent, D, nb, lr) {
  for (let q = 0; q < nb; q++) {
    const i = (Math.random() * D.n) | 0, z = agent.actor.forward(D.obs[i]), dz = new Float64Array(2);
    for (let k = 0; k < 2; k++) { const mu = Math.tanh(z[k]); dz[k] = (mu - D.act[i][k]) * (1 - mu * mu); }
    agent.actor.backward(dz);
  }
  agent.actor.step(lr, nb, 1.0);
}

// Behaviour cloning: the actor learns your steering and pedals from the sensor readings; the critic learns the returns.
async function learnFromDemos(T, epochs, onProgress) {
  const phys = T.kind === 'glb' ? 'real' : 'game', D = T.demo.dataset(phys);
  if (D.n < 300) throw new Error(D.n ? `Only ${D.n} recorded frames for this track type: drive a bit more (at least ~10 s).` : 'No recorded driving for this track type yet. Press D and drive first.');
  const wait = () => new Promise(r => setTimeout(r, 0)), ag = T.agent, n = D.n, idx = [];
  for (let i = 0; i < n; i++) { const reps = D.obs[i][RAYS.length] < 0.08 ? 4 : 1; for (let q = 0; q < reps; q++) idx.push(i); }   // standing starts are rare but vital
  const m = idx.length, x = new Float64Array(NIN);
  for (let epoch = 0; epoch < epochs; epoch++) {
    for (let i = m - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [idx[i], idx[j]] = [idx[j], idx[i]]; }
    for (let st = 0; st < m; st += 128) {
      const mb = idx.slice(st, st + 128);
      for (const i of mb) {
        x.set(D.obs[i]); for (let k = 0; k < RAYS.length; k++) x[k] = clamp(x[k] + randn() * 0.01, 0, 1);      // a little sensor noise so it does not memorise
        const z = ag.actor.forward(x), dz = new Float64Array(2);
        for (let k = 0; k < 2; k++) { const mu = Math.tanh(z[k]); dz[k] = (mu - D.act[i][k]) * (1 - mu * mu); }
        ag.actor.backward(dz);
        const v = ag.critic.forward(x)[0];
        ag.critic.backward([clamp(v - D.ret[i], -10, 10)]);
      }
      ag.actor.step(1e-3, mb.length, 1.0); ag.critic.step(2e-3, mb.length, 1.0);
      if ((st / 128) % 25 === 0) { onProgress && onProgress(`Learning from your laps... ${Math.round((epoch + st / m) / epochs * 100)}%`); await wait(); }
    }
  }
  ag.logStd.fill(-1.5);
  T.clearBuf(); T.respawn(); T.freezeLeft = 8;
  onProgress && onProgress('Test drive with what it learned...'); await wait();
  T.checkpoint();                                  // noise-free test drive from the line; keeps it as champion if it is the best so far
  return { frames: n, test: T.lastEval };
}
