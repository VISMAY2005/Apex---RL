/* Tracks. The real Nordschleife centreline (metres) is scaled to world pixels; a byte mask gives O(1) "on road?" tests. */
const PXM = 2.4;          // world pixels per real metre
const MS = 4;             // mask cell = 4 world px

function rng32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function practiceCentre() {
  const pts = [];
  for (let k = 0; k < 400; k++) {
    const a = 2 * Math.PI * k / 400;
    const r = 1 + 0.16 * Math.sin(2 * a + 0.6) + 0.11 * Math.sin(3 * a + 1.3) + 0.05 * Math.sin(5 * a + 0.2);
    pts.push([1500 * r * Math.cos(a), 950 * r * Math.sin(a)]);
  }
  return pts;
}

// Fills a triangle (cell coordinates) of a byte mask with value v. Cell centres are tested; a small tolerance closes seams between strips.
function fillTri(mask, mw, mh, p0, p1, p2, v) {
  const minx = Math.max(0, Math.floor(Math.min(p0[0], p1[0], p2[0]) - 1)), maxx = Math.min(mw - 1, Math.ceil(Math.max(p0[0], p1[0], p2[0]) + 1));
  const miny = Math.max(0, Math.floor(Math.min(p0[1], p1[1], p2[1]) - 1)), maxy = Math.min(mh - 1, Math.ceil(Math.max(p0[1], p1[1], p2[1]) + 1));
  const d = (p1[1] - p2[1]) * (p0[0] - p2[0]) + (p2[0] - p1[0]) * (p0[1] - p2[1]);
  if (Math.abs(d) < 1e-9) return;
  const e = 0.12;
  for (let y = miny; y <= maxy; y++) for (let x = minx; x <= maxx; x++) {
    const px = x + 0.5, py = y + 0.5;
    const a = ((p1[1] - p2[1]) * (px - p2[0]) + (p2[0] - p1[0]) * (py - p2[1])) / d;
    const b = ((p2[1] - p0[1]) * (px - p2[0]) + (p0[0] - p2[0]) * (py - p2[1])) / d;
    if (a >= -e && b >= -e && 1 - a - b >= -e) mask[y * mw + x] = v;
  }
}

class Track {
  constructor(kind) {
    this.kind = kind;
    let raw;
    if (kind === 'nord') {
      raw = NORDSCHLEIFE_M.map(p => [p[0] * PXM, p[1] * PXM]);
      this.hw = 30; this.kerb = 7; this.name = 'Nürburgring Nordschleife';
    } else if (kind === 'glb') {
      // Real Nordschleife 3D model (assets/nurburgring.glb): centreline, road width and wall positions were extracted from it by
      // tools/extract_glb.py. The model is in true metres, so the road is only ~8 m wide: cars use the 'real' physics profile.
      const G = this.glb = NORD_GLB;
      raw = G.x.map((x, i) => [x * PXM, G.z[i] * PXM]);
      this.hw = 3.9 * PXM; this.kerb = 0; this.name = 'Nürburgring (3D model, real walls)';
    } else {
      raw = practiceCentre(); this.hw = 40; this.kerb = 8; this.name = 'Practice circuit';
    }
    this.ms = MS;
    this.build(raw);
    if (this.glb) this.buildMaskGLB(); else this.buildMask();
    this.buildNear();
  }

  build(raw) {
    let minx = 1e9, miny = 1e9, maxx = -1e9, maxy = -1e9;
    for (const p of raw) { minx = Math.min(minx, p[0]); miny = Math.min(miny, p[1]); maxx = Math.max(maxx, p[0]); maxy = Math.max(maxy, p[1]); }
    const m = 360;
    this.ox = minx - m; this.oy = miny - m;          // world px -> source px offset (the GLB view needs it to place the car in the model)
    raw = raw.map(p => [p[0] - minx + m, p[1] - miny + m]);
    this.WW = Math.ceil(maxx - minx + 2 * m); this.WH = Math.ceil(maxy - miny + 2 * m);

    const n = raw.length, cum = [0];
    for (let i = 1; i <= n; i++) {
      const a = raw[i - 1], b = raw[i % n];
      cum.push(cum[i - 1] + Math.hypot(b[0] - a[0], b[1] - a[1]));
    }
    const total = cum[n], M = Math.round(total / 6), sp = total / M;
    let xs = new Float64Array(M), ys = new Float64Array(M), seg = 0;
    for (let i = 0; i < M; i++) {
      const d = i * sp;
      while (cum[seg + 1] < d) seg++;
      const f = (d - cum[seg]) / (cum[seg + 1] - cum[seg]), a = raw[seg], b = raw[(seg + 1) % n];
      xs[i] = a[0] + (b[0] - a[0]) * f; ys[i] = a[1] + (b[1] - a[1]) * f;
    }
    for (let pass = 0; pass < 5; pass++) {          // soften GPS jitter
      const nx2 = new Float64Array(M), ny2 = new Float64Array(M);
      for (let i = 0; i < M; i++) {
        const a = (i - 1 + M) % M, b = (i + 1) % M;
        nx2[i] = (xs[a] + 2 * xs[i] + xs[b]) / 4; ny2[i] = (ys[a] + 2 * ys[i] + ys[b]) / 4;
      }
      xs = nx2; ys = ny2;
    }
    const tx = new Float64Array(M), ty = new Float64Array(M), nx = new Float64Array(M), ny = new Float64Array(M);
    for (let i = 0; i < M; i++) {
      const a = (i - 1 + M) % M, b = (i + 1) % M;
      const dx = xs[b] - xs[a], dy = ys[b] - ys[a], l = Math.hypot(dx, dy) || 1;
      tx[i] = dx / l; ty[i] = dy / l; nx[i] = -ty[i]; ny[i] = tx[i];
    }
    Object.assign(this, { xs, ys, tx, ty, nx, ny, M, spacing: sp, lapLen: M * sp });
  }

  buildMask() {
    const r = this.hw + this.kerb, mw = Math.ceil(this.WW / MS), mh = Math.ceil(this.WH / MS), mask = new Uint8Array(mw * mh), rc = r / MS;
    for (let i = 0; i < this.M; i++) {
      const cx = this.xs[i] / MS, cy = this.ys[i] / MS;
      for (let y = Math.max(0, Math.floor(cy - rc)); y <= Math.min(mh - 1, Math.ceil(cy + rc)); y++) {
        const dy = y - cy, hwid = Math.sqrt(Math.max(0, rc * rc - dy * dy));
        const x0 = Math.max(0, Math.floor(cx - hwid)), x1 = Math.min(mw - 1, Math.ceil(cx + hwid));
        mask.fill(1, y * mw + x0, y * mw + x1 + 1);
      }
    }
    this.mask = mask; this.mw = mw; this.mh = mh;
  }

  // coarse "keep trees away from here" grid
  buildNear() {
    const C = 64, gw = Math.ceil(this.WW / C), gh = Math.ceil(this.WH / C), grid = new Uint8Array(gw * gh), R = (this.hw + this.kerb + 70) / C;
    for (let i = 0; i < this.M; i += 2) {
      const cx = this.xs[i] / C, cy = this.ys[i] / C;
      for (let y = Math.max(0, Math.floor(cy - R)); y <= Math.min(gh - 1, Math.ceil(cy + R)); y++)
        for (let x = Math.max(0, Math.floor(cx - R)); x <= Math.min(gw - 1, Math.ceil(cx + R)); x++) grid[y * gw + x] = 1;
    }
    this.near = grid; this.gw = gw; this.gh = gh;
  }
  nearRoad(x, y) {
    const xi = (x / 64) | 0, yi = (y / 64) | 0;
    if (x < 0 || y < 0 || xi >= this.gw || yi >= this.gh) return true;
    return this.near[yi * this.gw + xi] === 1;
  }

  onRoad(x, y) {                                    // inside the drivable corridor (road, or - on the 3D-model track - the grass strip up to the wall)
    if (x < 0 || y < 0) return false;
    const xi = (x / this.ms) | 0, yi = (y / this.ms) | 0;
    if (xi >= this.mw || yi >= this.mh) return false;
    return this.mask[yi * this.mw + xi] > 0;
  }

  surface(x, y) {                                   // 0 = wall / out of bounds, 1 = asphalt, 2 = grass between road and wall
    if (x < 0 || y < 0) return 0;
    const xi = (x / this.ms) | 0, yi = (y / this.ms) | 0;
    if (xi >= this.mw || yi >= this.mh) return 0;
    return this.mask[yi * this.mw + xi];
  }

  // Corridor of the 3D-model track: asphalt (1) from -roadR..+roadL, grass (2) out to the wall (or to an open-grass edge where the model has no wall).
  buildMaskGLB() {
    const G = this.glb, ms = this.ms = 3, mw = Math.ceil(this.WW / ms), mh = Math.ceil(this.WH / ms), mask = new Uint8Array(mw * mh), M = this.M;
    // build() re-spaces the centreline evenly, which can change the sample count by one: map the per-sample arrays across by fraction of the lap
    const at = (arr, i) => { const f = i * G.M / M, a = Math.floor(f) % G.M, b = (a + 1) % G.M, u = f - Math.floor(f); return arr[a] + (arr[b] - arr[a]) * u; };
    const near = (arr, i) => arr[Math.round(i * G.M / M) % G.M];
    const L = new Float32Array(M), R = new Float32Array(M), BL = new Float32Array(M), BR = new Float32Array(M), WLf = new Uint8Array(M), WRf = new Uint8Array(M), EL = new Float32Array(M);
    for (let i = 0; i < M; i++) { L[i] = at(G.roadL, i) * PXM; R[i] = at(G.roadR, i) * PXM; BL[i] = at(G.bndL, i) * PXM; BR[i] = at(G.bndR, i) * PXM; WLf[i] = near(G.wallL, i); WRf[i] = near(G.wallR, i); EL[i] = at(G.y, i); }
    const P = (i, o) => { const j = i % M; return [(this.xs[j] + this.nx[j] * o) / ms, (this.ys[j] + this.ny[j] * o) / ms]; };
    const strip = (offA, offB, v) => {
      for (let i = 0; i < M; i++) {
        const k = (i + 1) % M, a = P(i, offA(i)), b = P(i, offB(i)), c = P(k, offB(k)), d = P(k, offA(k));
        fillTri(mask, mw, mh, a, b, c, v); fillTri(mask, mw, mh, a, c, d, v);
      }
    };
    strip(i => -BR[i], i => BL[i], 2);
    strip(i => -R[i], i => L[i], 1);
    this.mask = mask; this.mw = mw; this.mh = mh;
    this.roadL = L; this.roadR = R; this.bndL = BL; this.bndR = BR;
    this.wallL = WLf; this.wallR = WRf; this.elev = EL;
  }

  locate(x, y, hint) {
    let best = hint, bd = Infinity;
    for (let k = -16; k <= 16; k++) {
      const i = (hint + k + this.M) % this.M, d = (x - this.xs[i]) ** 2 + (y - this.ys[i]) ** 2;
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }
}
