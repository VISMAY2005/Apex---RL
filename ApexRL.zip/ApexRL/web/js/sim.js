/* Car physics, bumper sensors (ray casts) and the reward function. Units: world pixels, 2.4 px = 1 metre. */
const DT = 1 / 30;
// Physics profiles. 'game' = the original arcade car on the wide GPS ribbon (car ~16 m long on a 25 m road).
// 'real' = true-size car (4.6 x 1.9 m) for the 3D-model track whose road is only ~8 m wide. 2.4 px = 1 m. Steering gets heavier with speed (VSTEER).
const PHYS = {
  game: { MAXV: 200, CL: 38, CW: 20, WB: 24, MAXSTEER: 0.5, AY: 260, ACC: 150, BRK: 320, DRAG: 0.0026, VSTEER: 0, RANGE: 300, RSTEP: 5 },
  real: { MAXV: 170, CL: 11, CW: 4.6, WB: 6.5, MAXSTEER: 0.5, AY: 52, ACC: 21.6, BRK: 40, DRAG: 0.00075, VSTEER: 35, RANGE: 300, RSTEP: 3 },
};
let MAXV, CL, CW, WB, MAXSTEER, AY, ACC, BRK, DRAG, VSTEER, RANGE, RSTEP;
function setPhysics(name) { ({ MAXV, CL, CW, WB, MAXSTEER, AY, ACC, BRK, DRAG, VSTEER, RANGE, RSTEP } = PHYS[name]); }
setPhysics('game');
const RAYS = [-80, -50, -28, -12, 0, 12, 28, 50, 80].map(d => d * Math.PI / 180);
const NIN = RAYS.length + 5;          // 9 rays + speed + steering + slip + wetness + night. No map, no position.
const wrapA = a => Math.atan2(Math.sin(a), Math.cos(a));
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

class Car {
  constructor() {
    this.reading = new Float64Array(RAYS.length);
    this.hx = new Float64Array(RAYS.length);
    this.hy = new Float64Array(RAYS.length);
    this.o = new Float64Array(NIN);
    this.cmdS = 0; this.cmdT = 0; this.hb = 0; this.ox = 0; this.oy = 0;
  }

  reset(tr, startPx, v0) {
    const i = Math.floor(startPx / tr.spacing) % tr.M, lat = (Math.random() - 0.5) * tr.hw * 0.5;
    this.idx = i; this.startPx = startPx;
    this.x = tr.xs[i] + tr.nx[i] * lat; this.y = tr.ys[i] + tr.ny[i] * lat;
    this.h = Math.atan2(tr.ty[i], tr.tx[i]) + (Math.random() - 0.5) * 0.2;
    this.v = startPx < 1 ? 0 : (v0 ?? 70); this.steer = 0; this.vang = this.h; this.slip = 0;
    this.dist = 0; this.mark = 0; this.steps = 0; this.ret = 0; this.lat = lat; this.lapTime = null;
    this.px = this.x; this.py = this.y; this.ph = this.h; this.cmdS = 0; this.cmdT = 0; this.hb = 0;
  }

  // Cast the 9 bumper rays by marching until they leave the road. Night and rain shorten and blur them.
  sense(tr) {
    const ox = this.x + Math.cos(this.h) * CL / 2, oy = this.y + Math.sin(this.h) * CL / 2;
    const rng = RANGE * (1 - 0.42 * ENV.night) * (1 - 0.22 * ENV.rain), sig = 0.01 + 0.03 * ENV.rain + 0.02 * ENV.night;
    for (let i = 0; i < RAYS.length; i++) {
      const a = this.h + RAYS[i], cx = Math.cos(a), cy = Math.sin(a);
      let d = 0;
      while (d < rng && tr.onRoad(ox + cx * d, oy + cy * d)) d += RSTEP;
      d = Math.min(d, rng);
      this.hx[i] = ox + cx * d; this.hy[i] = oy + cy * d;
      const nz = clamp(d / RANGE * (1 + sig * randn()), 0, 1);
      this.reading[i] = nz; this.o[i] = nz;
    }
    this.ox = ox; this.oy = oy;
    const n = RAYS.length;
    this.o[n] = this.v / MAXV;
    this.o[n + 1] = this.steer / MAXSTEER;
    this.o[n + 2] = clamp(this.slip / 0.5, -1, 1);
    this.o[n + 3] = ENV.wet;
    this.o[n + 4] = ENV.night;
    return this.o;
  }

  // One physics step. kind: 'crash' | 'stall' | 'lap' | null
  step(tr, a, hp) {
    this.px = this.x; this.py = this.y; this.ph = this.h;
    const s = clamp(a[0], -1, 1), th = clamp(a[1], -1, 1), hb = a[2] ? clamp(a[2], 0, 1) : 0;   // a[2] = handbrake (only the human uses it; the AI sends 2 numbers)
    this.cmdS = s; this.cmdT = th; this.hb = hb;
    let grip = 1 - 0.42 * ENV.wet;                                     // wet road = less grip
    const onGrass = tr.glb ? tr.surface(this.x, this.y) === 2 : false; // 3D-model track: the strip between asphalt and wall
    if (onGrass) grip *= 0.55;
    this.steer += (s * MAXSTEER - this.steer) * 0.3;
    let v = this.v + ((th >= 0 ? th * (1 - hb) * ACC * (0.55 + 0.45 * grip) : th * BRK * grip) - hb * 0.35 * BRK * grip - DRAG * this.v * this.v - (onGrass ? 0.9 * this.v : 0)) * DT;
    v = clamp(v, 0, MAXV);
    const ss = VSTEER ? 1 / (1 + (v / VSTEER) ** 2) : 1;               // power steering: less lock at speed
    let yaw = (v / WB) * Math.tan(this.steer * ss) * (1 + 0.5 * hb);   // handbrake: rear wheels lock, the nose swings round more
    const ay = v * Math.abs(yaw), ayMax = AY * grip;
    if (ay > ayMax) { const f = ayMax / ay; yaw *= f; v *= 1 - (1 - f) * 0.05; }   // understeer: too fast for the corner
    this.h += yaw * DT;
    // the car's direction of travel lags behind where it points; on a wet road it lags much more (slides)
    const gl = grip * (1 - 0.7 * hb);                                   // ...and the car keeps sliding in its old direction (a drift)
    this.vang += wrapA(this.h - this.vang) * Math.min(1, 14 * gl * gl * DT);
    this.slip = wrapA(this.h - this.vang);
    v -= v * Math.abs(Math.sin(this.slip)) * 1.5 * DT;                          // sliding scrubs speed
    this.v = Math.max(0, v);
    this.x += Math.cos(this.vang) * this.v * DT; this.y += Math.sin(this.vang) * this.v * DT;
    this.steps++;

    const c = Math.cos(this.h), sn = Math.sin(this.h);
    let crashed = false;
    for (const [fx, fy] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) {
      const lx = fx * CL / 2, ly = fy * CW / 2;
      if (!tr.onRoad(this.x + c * lx - sn * ly, this.y + sn * lx + c * ly)) { crashed = true; break; }
    }

    const old = this.idx;
    this.idx = tr.locate(this.x, this.y, old);
    let d = this.idx - old;
    if (d > tr.M / 2) d -= tr.M; else if (d < -tr.M / 2) d += tr.M;
    const dProg = d * tr.spacing;
    this.dist += dProg;
    this.lat = (this.x - tr.xs[this.idx]) * tr.nx[this.idx] + (this.y - tr.ys[this.idx]) * tr.ny[this.idx];

    // "too fast for the road you can see": could the car stop within the clear distance its centre sensors show?
    const ahead = Math.min(this.reading[3], this.reading[4], this.reading[5]) * RANGE, vSafe = Math.sqrt(2 * BRK * 0.625 * ahead) * 0.8;
    let r = hp.wProg * dProg + hp.wSpeed * (this.v / MAXV) - hp.wCenter * (this.lat / tr.hw) ** 2 - hp.wSafe * Math.max(0, this.v - vSafe) / MAXV;
    let kind = null;
    if (crashed) { r -= hp.crash; kind = 'crash'; }
    else if (this.startPx + this.dist >= tr.lapLen) { kind = 'lap'; if (this.startPx < 1) this.lapTime = this.steps * DT; }
    else if (this.dist < -60) { r -= hp.crash; kind = 'crash'; }                      // wrong way round
    else if (this.steps % 90 === 0) {                                                  // not making progress
      if (this.dist - this.mark < 12) { r -= hp.crash * 0.5; kind = 'stall'; }
      this.mark = this.dist;
    }
    this.ret += r;
    return { r, done: kind !== null, kind };
  }
}
