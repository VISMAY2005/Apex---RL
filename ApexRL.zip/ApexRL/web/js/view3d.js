/* Chase-camera 3D view in the spirit of 90s/2000s racers: low-resolution, nearest-neighbour pixels, distance fog, billboard trees.
   The road/grass are the SAME world map as the top-down view, projected with true perspective ("mode 7" style: every screen pixel looks up
   the world texture). Walls, trees, lamps, the start gantry and cars are drawn as depth-sorted sprites / quads. Flat world: no hills (the GPS trace has no altitude). */
const CAR3D = { width: 24 };            // how wide the rear sprite appears, in world px (the car body is 20)
const GRASS_PX = 0xFF000000 | (46 << 16) | (104 << 8) | 46;

class View3D {
  constructor() {
    this.cv = document.createElement('canvas'); this.lc = document.createElement('canvas'); this.g = null;
    this.camX = 0; this.camY = 0; this.camYaw = 0; this.camDist = 48; this.camH = 15;
    this.shake = 0; this.flash = 0; this.snap = true; this.tr = null; this.sky = {}; this.fb = null; this.treeFb = null;
    this.drops = Array.from({ length: 180 }, () => ({ x: Math.random(), y: Math.random(), v: 0.8 + Math.random() * 0.8 }));
    this.setRes(270, 16 / 9);
  }

  setRes(h, aspect) {
    this.H = h; this.W = Math.max(160, Math.round(h * aspect / 2) * 2); this.hor = Math.floor(h * 0.40); this.gh = h - this.hor;
    this.cv.width = this.lc.width = this.W; this.cv.height = this.lc.height = h;
    this.g = this.cv.getContext('2d'); this.g.imageSmoothingEnabled = false; this.L = this.lc.getContext('2d');
    this.img = this.g.createImageData(this.W, this.gh); this.buf = new Uint32Array(this.img.data.buffer);
    this.vig = null;
  }

  setTrack(tr, lamps) {
    this.tr = tr; this.lamps = lamps; this.cols = Math.ceil(tr.WW / TS); this.rows = Math.ceil(tr.WH / TS);
    this.data = new Array(this.cols * this.rows).fill(null); this.order = []; this.treeMap = new Map();
    this.gc = new TileCache(tr, { flat: true, scale: 1 }); this.snap = true; this.sky = {};
  }

  /* ---------- ground texture data ---------- */
  tileData(tx, ty, build) {
    if (tx < 0 || ty < 0 || tx >= this.cols || ty >= this.rows) return null;
    const k = ty * this.cols + tx; let d = this.data[k];
    if (d || !build) return d;
    d = new Uint32Array(this.gc.build(tx, ty).getContext('2d').getImageData(0, 0, TS, TS).data.buffer);
    this.data[k] = d; this.order.push(k);
    if (this.order.length > 72) this.data[this.order.shift()] = null;
    return d;
  }
  ensure(cx, cy, fx, fy, rx, ry, far) {
    const want = [], seen = new Set();
    for (const d of [0, 80, 180, 300, 450, 620, 800, far]) for (const l of [0, -0.45, 0.45]) {
      const x = cx + fx * d + rx * l * d, y = cy + fy * d + ry * l * d, tx = Math.floor(x / TS), ty = Math.floor(y / TS), k = ty * this.cols + tx;
      if (tx < 0 || ty < 0 || tx >= this.cols || ty >= this.rows || seen.has(k)) continue;
      seen.add(k); if (!this.data[k]) want.push([tx, ty]);
    }
    for (let i = 0; i < Math.min(3, want.length); i++) this.tileData(want[i][0], want[i][1], true);
  }

  /* ---------- generated art (used when no PNG is supplied) ---------- */
  skyPano(kind) {
    if (this.sky[kind]) return this.sky[kind];
    const w = 1024, h = 160, c = document.createElement('canvas'); c.width = w; c.height = h;
    const g = c.getContext('2d'), day = kind === 'day', R = rng32(day ? 11 : 12);
    const gr = g.createLinearGradient(0, 0, 0, h);
    if (day) { gr.addColorStop(0, '#3f7fd0'); gr.addColorStop(0.6, '#8fbbe8'); gr.addColorStop(1, '#cfe3f2'); }
    else { gr.addColorStop(0, '#03050d'); gr.addColorStop(0.7, '#0a1028'); gr.addColorStop(1, '#1a2441'); }
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    if (!day) {
      for (let i = 0; i < 260; i++) { g.fillStyle = `rgba(255,255,255,${0.25 + R() * 0.7})`; g.fillRect((R() * w) | 0, (R() * h * 0.65) | 0, 1, 1); }
      const mg = g.createRadialGradient(720, 38, 2, 720, 38, 34); mg.addColorStop(0, 'rgba(255,255,235,1)'); mg.addColorStop(0.35, 'rgba(235,240,255,.9)'); mg.addColorStop(1, 'rgba(180,200,255,0)');
      g.fillStyle = mg; g.fillRect(680, 0, 80, 80);
    } else {
      for (let n = 0; n < 12; n++) {
        const cx = R() * w, cy = 14 + R() * 52, k = 5 + ((R() * 5) | 0);
        for (const off of [0, -w, w]) for (let i = 0; i < k; i++) {
          const x = cx + off + (i - k / 2) * 14 + R() * 8, y = cy + R() * 8 - Math.abs(i - k / 2) * 1.5, rw = 16 + R() * 18, rh = 7 + R() * 7;
          g.fillStyle = 'rgba(255,255,255,.88)'; g.beginPath(); g.ellipse(x, y, rw, rh, 0, 0, 7); g.fill();
          g.fillStyle = 'rgba(190,205,225,.5)'; g.beginPath(); g.ellipse(x, y + rh * 0.5, rw * 0.9, rh * 0.5, 0, 0, 7); g.fill();
        }
      }
    }
    const teeth = Array.from({ length: Math.ceil(w / 3) }, () => R());
    const layers = day ? [['#8aa6bd', 16, 0.74, 1], ['#5f8a63', 11, 0.86, 2], ['#2f5f3a', 8, 0.96, 3]] : [['#10182b', 16, 0.74, 1], ['#0b1220', 11, 0.86, 2], ['#070c16', 8, 0.96, 3]];
    for (const [col, amp, base, m] of layers) {                       // rolling Eifel hills with a ragged tree line; all terms tile seamlessly
      g.fillStyle = col; g.beginPath(); g.moveTo(0, h);
      for (let x = 0; x <= w; x += 2) {
        const t = x / w * 2 * Math.PI, y = h * base - amp * (Math.sin(t * 2 * m + m) + 0.6 * Math.sin(t * 5 * m + 1.3 * m) + 0.3 * Math.sin(t * 11 * m)) - teeth[((x / 3) | 0) % teeth.length] * 3.5 * m;
        g.lineTo(x, y);
      }
      g.lineTo(w, h); g.closePath(); g.fill();
    }
    return (this.sky[kind] = c);
  }

  treeSprites() {
    if (art3d.trees.length) return art3d.trees;
    if (this.treeFb) return this.treeFb;
    const out = [];
    for (let v = 0; v < 4; v++) {
      const c = document.createElement('canvas'); c.width = 48; c.height = 80; const g = c.getContext('2d');
      g.fillStyle = '#3a2a1c'; g.fillRect(22, 56, 5, 24);
      const dark = ['#17401f', '#1d4d27', '#235a2d', '#2a6a35'][v], light = ['#2c6d38', '#357b40', '#3f8a4a', '#4a9a55'][v];
      if (v < 2) { for (let i = 0; i < 4; i++) { const y = 8 + i * 14, w = 11 + i * 5; g.fillStyle = dark; g.beginPath(); g.moveTo(24, y - 8); g.lineTo(24 + w, y + 14); g.lineTo(24 - w, y + 14); g.closePath(); g.fill(); g.fillStyle = light; g.beginPath(); g.moveTo(24, y - 8); g.lineTo(24 + w * 0.5, y + 14); g.lineTo(24 - w * 0.2, y + 14); g.closePath(); g.fill(); } }
      else { for (const [x, y, r] of [[24, 30, 19], [14, 40, 13], [34, 40, 13], [24, 20, 12]]) { g.fillStyle = dark; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); g.fillStyle = light; g.beginPath(); g.arc(x - 3, y - 3, r * 0.65, 0, 7); g.fill(); } }
      out.push(c);
    }
    return (this.treeFb = out);
  }

  carSprite() {
    if (this.fb) return this.fb;
    const c = document.createElement('canvas'); c.width = 160; c.height = 90; const g = c.getContext('2d');
    g.fillStyle = '#15161a'; g.fillRect(8, 56, 20, 32); g.fillRect(132, 56, 20, 32);
    g.fillStyle = '#23252b'; g.fillRect(20, 4, 120, 10);
    g.fillStyle = '#b9bec7'; g.fillRect(24, 40, 112, 38);
    g.fillStyle = '#1b3f8f'; g.fillRect(66, 40, 28, 38);
    g.fillStyle = '#1a2128'; g.beginPath(); g.moveTo(40, 20); g.lineTo(120, 20); g.lineTo(134, 42); g.lineTo(26, 42); g.closePath(); g.fill();
    g.fillStyle = '#e02a2a'; g.fillRect(28, 46, 26, 9); g.fillRect(106, 46, 26, 9);
    return (this.fb = c);
  }

  fogRGB() {
    const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
    return mix(mix([190, 212, 230], [128, 138, 148], ENV.rain * 0.9), [9, 13, 26], ENV.night).map(Math.round);
  }

  /* ---------- one frame ---------- */
  render(st) {
    const { W, H, hor, gh, g, tr } = this, c = st.car, dt = Math.min(0.1, st.dt);
    const sK = clamp(c.v / MAXV, 0, 1), wantYaw = Math.atan2(Math.sin(c.h) * 0.55 + Math.sin(c.vang) * 0.45, Math.cos(c.h) * 0.55 + Math.cos(c.vang) * 0.45);
    if (this.snap || Math.hypot(c.x - this.lastX, c.y - this.lastY) > 300) { this.camYaw = wantYaw; this.snap = false; }
    this.lastX = c.x; this.lastY = c.y;
    this.camYaw += wrapA(wantYaw - this.camYaw) * Math.min(1, dt * 7);
    const cd = this.camDist * (1 + 0.12 * sK), camH = this.camH, yaw = this.camYaw;
    const fwx = Math.cos(yaw), fwy = Math.sin(yaw), rx = -fwy, ry = fwx, cx = c.x - fwx * cd, cy = c.y - fwy * cd;
    const hfov = (66 + 20 * sK) * Math.PI / 180, f = (H * 16 / 9 / 2) / Math.tan(hfov / 2);
    const far = 900 * (1 - 0.4 * ENV.rain) * (1 - 0.25 * ENV.night), fogNear = far * 0.3, fog = this.fogRGB();
    const fogPx = 0xFF000000 | (fog[2] << 16) | (fog[1] << 8) | fog[0];
    this.shake = Math.max(0, this.shake - dt * 2.5); this.flash = Math.max(0, this.flash - dt * 2.2);

    /* sky */
    g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over';
    const pw = W * 5, u = (((yaw / (2 * Math.PI)) % 1) + 1) % 1 * pw;
    const day = art3d.skyDay || this.skyPano('day'), night = art3d.skyNight || this.skyPano('night');
    g.drawImage(day, 0, 0, day.width, day.height, -u, 0, pw, hor); g.drawImage(day, 0, 0, day.width, day.height, pw - u, 0, pw, hor);
    if (ENV.night > 0.01) { g.globalAlpha = ENV.night; g.drawImage(night, 0, 0, night.width, night.height, -u, 0, pw, hor); g.drawImage(night, 0, 0, night.width, night.height, pw - u, 0, pw, hor); g.globalAlpha = 1; }
    const dusk = Math.max(0, 1 - Math.abs(ENV.night - 0.4) / 0.4) * (1 - ENV.rain * 0.6);
    if (dusk > 0.02) { const dg = g.createLinearGradient(0, hor * 0.3, 0, hor); dg.addColorStop(0, 'rgba(255,120,60,0)'); dg.addColorStop(1, `rgba(255,140,70,${0.55 * dusk})`); g.fillStyle = dg; g.fillRect(0, 0, W, hor); }
    if (ENV.rain > 0.02) { g.fillStyle = `rgba(112,122,134,${0.7 * ENV.rain})`; g.fillRect(0, 0, W, hor); }
    const hz = g.createLinearGradient(0, hor - 26, 0, hor); hz.addColorStop(0, `rgba(${fog},0)`); hz.addColorStop(1, `rgba(${fog},1)`); g.fillStyle = hz; g.fillRect(0, hor - 26, W, 26);

    /* ground: every pixel below the horizon looks up the world texture */
    this.ensure(cx, cy, fwx, fwy, rx, ry, far);
    const buf = this.buf, cols = this.cols, rows = this.rows, data = this.data, wet = ENV.wet, dk = 1 - 0.22 * wet, inv = 1 / TS;
    for (let r = 0; r < gh; r++) {
      const zf = f * camH / (r + 0.7), base = r * W;
      if (zf > far) { buf.fill(fogPx, base, base + W); continue; }
      const fa = clamp((zf - fogNear) / (far - fogNear), 0, 1), fa2 = fa * fa * (3 - 2 * fa);
      const stx = rx * zf / f, sty = ry * zf / f;
      let wx = cx + fwx * zf - stx * W / 2, wy = cy + fwy * zf - sty * W / 2;
      for (let x = 0; x < W; x++) {
        wx += stx; wy += sty; let px = GRASS_PX;
        if (wx >= 0 && wy >= 0) {
          const tx = (wx * inv) | 0, ty = (wy * inv) | 0;
          if (tx < cols && ty < rows) { const t = data[ty * cols + tx]; if (t) px = t[(((wy - ty * TS) | 0) * TS) + ((wx - tx * TS) | 0)]; }
        }
        if (fa2 > 0.003 || wet > 0.02) {
          let r0 = (px & 255) * dk, g0 = ((px >> 8) & 255) * dk, b0 = ((px >> 16) & 255) * dk;
          r0 += (fog[0] - r0) * fa2; g0 += (fog[1] - g0) * fa2; b0 += (fog[2] - b0) * fa2;
          px = 0xFF000000 | ((b0 | 0) << 16) | ((g0 | 0) << 8) | (r0 | 0);
        }
        buf[base + x] = px;
      }
    }
    g.putImageData(this.img, 0, hor);

    /* sprites and quads, far to near */
    const items = [], push = (z, fn) => items.push({ z, fn });
    const fogA = z => 1 - clamp((z - fogNear) / (far - fogNear), 0, 1) * 0.92;
    const gy = z => hor + f * camH / z, X = (dx, dy, z) => W / 2 + f * (dx * rx + dy * ry) / z;

    /* sensor rays on the ground (drawn first so cars, walls and trees cover them) */
    if (st.showRays) {
      const rr = st.rays; g.lineWidth = 1;
      for (let i = 0; i < RAYS.length; i++) {
        const ax = rr.ox - cx, ay = rr.oy - cy, bx = rr.hx[i] - cx, by = rr.hy[i] - cy, za = ax * fwx + ay * fwy, zb = bx * fwx + by * fwy; if (za < 4 || zb < 4) continue;
        g.strokeStyle = `hsla(${Math.round(rr.reading[i] * 120)},95%,58%,.9)`; g.beginPath(); g.moveTo(X(ax, ay, za), hor + f * (camH - 2) / za); g.lineTo(X(bx, by, zb), hor + f * (camH - 2) / zb); g.stroke();
      }
    }


    const trees = this.treeSprites(), TR = Math.ceil(far / TS) + 1, tcx = Math.floor(cx / TS), tcy = Math.floor(cy / TS);
    for (let ty = tcy - TR; ty <= tcy + TR; ty++) for (let tx = tcx - TR; tx <= tcx + TR; tx++) {
      for (const t of this.treesOf(tx, ty)) {
        const dx = t[0] - cx, dy = t[1] - cy, z = dx * fwx + dy * fwy; if (z < 10 || z > far) continue;
        const sx = X(dx, dy, z), sh = f * t[2] / z; if (sh < 3 || sx < -sh || sx > W + sh) continue;
        push(z, () => { const s = trees[t[3] % trees.length], w = sh * s.width / s.height; g.globalAlpha = fogA(z); g.drawImage(s, sx - w / 2, gy(z) - sh, w, sh); });
      }
    }
    const { xs, ys, nx, ny, M, hw, kerb } = tr;
    for (const side of [1, -1]) for (let k = -14; k <= 135; k += 3) {                      // barrier: tyre stack + red/white band + guard rail
      const i = (st.idx + k + M) % M, j = (i + 3) % M, off = side * (hw + kerb + 3);
      const ax = xs[i] + nx[i] * off - cx, ay = ys[i] + ny[i] * off - cy, bx = xs[j] + nx[j] * off - cx, by = ys[j] + ny[j] * off - cy;
      const za = ax * fwx + ay * fwy, zb = bx * fwx + by * fwy; if (za < 6 || zb < 6 || (za > far && zb > far)) continue;
      const xa = X(ax, ay, za), xb = X(bx, by, zb), ba = gy(za), bb = gy(zb), band = Math.floor(i / 3) & 1;
      push((za + zb) / 2, () => {
        g.globalAlpha = fogA((za + zb) / 2);
        const q = (h0, h1, col) => { g.fillStyle = col; g.beginPath(); g.moveTo(xa, ba - f * h0 / za); g.lineTo(xb, bb - f * h0 / zb); g.lineTo(xb, bb - f * h1 / zb); g.lineTo(xa, ba - f * h1 / za); g.closePath(); g.fill(); };
        q(0, 4.2, '#202226'); q(4.2, 6, band ? '#d4202a' : '#f2f2f2'); q(6, 7.2, '#b5b9c2');
      });
    }
    for (const [lx, ly] of this.lamps) {                                                     // lamp posts
      const dx = lx - cx, dy = ly - cy, z = dx * fwx + dy * fwy; if (z < 10 || z > far) continue;
      const sx = X(dx, dy, z); if (sx < -20 || sx > W + 20) continue;
      push(z, () => {
        g.globalAlpha = fogA(z); const b = gy(z), t = hor + f * (camH - 30) / z;
        g.strokeStyle = '#4a4e57'; g.lineWidth = Math.max(1, f * 1.4 / z); g.beginPath(); g.moveTo(sx, b); g.lineTo(sx, t); g.stroke();
        g.fillStyle = ENV.night > 0.3 ? '#fff3c4' : '#9aa0aa'; const r = Math.max(1, f * 2.4 / z); g.fillRect(sx - r, t - r, r * 2, r);
      });
    }
    { const gxw = xs[0] - cx, gyw = ys[0] - cy, z = gxw * fwx + gyw * fwy;                   // start / finish gantry
      if (z > 8 && z < far) {
        const half = hw + kerb + 8, ox = nx[0] * half, oy = ny[0] * half, za = z;
        const xl = X(gxw - ox, gyw - oy, za), xr = X(gxw + ox, gyw + oy, za), b = gy(za);
        push(za, () => {
          g.globalAlpha = fogA(za); const pw2 = Math.max(1.5, f * 3 / za), top = b - f * 46 / za, bot = b - f * 36 / za;
          g.fillStyle = '#2b2e35'; g.fillRect(xl - pw2 / 2, top, pw2, b - top); g.fillRect(xr - pw2 / 2, top, pw2, b - top);
          const n = 14; for (let q = 0; q < n; q++) for (let rr = 0; rr < 2; rr++) { g.fillStyle = (q + rr) & 1 ? '#f4f4f4' : '#15161a'; const x0 = xl + (xr - xl) * q / n, x1 = xl + (xr - xl) * (q + 1) / n; g.fillRect(x0, top + (bot - top) * rr / 2, x1 - x0 + 0.5, (bot - top) / 2 + 0.5); }
        });
      } }
    for (const q of st.spray) {                                                              // spray behind the car
      const dx = q.x - cx, dy = q.y - cy, z = dx * fwx + dy * fwy; if (z < 8) continue;
      const sx = X(dx, dy, z), sy = hor + f * (camH - 1.5) / z, rr = f * (1.1 + (0.7 - q.life) * 3) / z;
      push(z - 0.5, () => { g.globalAlpha = q.life * 0.35; g.fillStyle = '#e1ebfa'; g.beginPath(); g.arc(sx, sy, rr, 0, 7); g.fill(); });
    }
    const drawCar = (p, alpha, lit, brake, player) => {
      const dx = p.x - cx, dy = p.y - cy, z = dx * fwx + dy * fwy; if (z < 8) return;
      const sx = X(dx, dy, z), b = gy(z), rel = wrapA(p.h - yaw), w = f * CAR3D.width / z;
      let spr = (rel > 0.16 && art3d.right) || (rel < -0.16 && art3d.left) || ((lit > 0.5 && art3d.backLights) || art3d.back || this.carSprite());
      const h = w * spr.height / spr.width, hasArt = !!art3d.back;
      push(z, () => {
        g.globalAlpha = alpha * 0.4; g.fillStyle = '#000'; g.beginPath(); g.ellipse(sx, b - 1, w * 0.56, Math.max(1.5, w * 0.1), 0, 0, 7); g.fill();
        const rot = clamp(rel, -0.7, 0.7) * (hasArt && (art3d.left || art3d.right) ? 0.25 : 0.5); if (player) this.carPose = { spr, sx, b, w, h, rot };   // remembered so the headlight beam can be hidden behind the car
        g.save(); g.translate(sx, b); g.rotate(rot); g.globalAlpha = alpha; g.drawImage(spr, -w / 2, -h, w, h);
        const glow = clamp(lit * (art3d.backLights && lit > 0.5 ? 0.0 : 0.7) + (brake ? 0.9 : 0), 0, 1);           // tail / brake lights
        if (glow > 0.02) { g.globalCompositeOperation = 'lighter'; g.globalAlpha = alpha * glow; for (const sxx of [-0.34, 0.34]) { const px = sxx * w, py = -h * 0.5, rr = Math.max(2, w * 0.14), gr = g.createRadialGradient(px, py, 0, px, py, rr); gr.addColorStop(0, 'rgba(255,60,50,1)'); gr.addColorStop(1, 'rgba(255,0,0,0)'); g.fillStyle = gr; g.fillRect(px - rr, py - rr, rr * 2, rr * 2); } }
        g.restore();
      });
    };
    for (const gp of st.ghosts) drawCar(gp, 0.5, st.mix, false, false);
    drawCar(c, 1, st.mix, c.cmdT < -0.15, true);
    items.sort((a, b) => b.z - a.z);
    for (const it of items) it.fn();
    g.globalAlpha = 1;

    /* weather tint, night darkness with lamp pools + headlight cone */
    if (ENV.rain > 0.02) { g.fillStyle = `rgba(70,82,96,${0.18 * ENV.rain})`; g.fillRect(0, 0, W, H); }
    const dark = clamp(0.84 * ENV.night + 0.18 * ENV.rain * (1 - ENV.night), 0, 0.9), lampsOn = clamp((ENV.night - 0.25) / 0.5, 0, 1), headOn = Math.max(clamp((ENV.night - 0.25) / 0.5, 0, 1), clamp((ENV.rain - 0.45) / 0.4, 0, 1));
    if (dark > 0.02) {
      const L = this.L; L.setTransform(1, 0, 0, 1, 0, 0); L.globalCompositeOperation = 'source-over'; L.clearRect(0, 0, W, H); L.fillStyle = `rgba(3,7,20,${dark})`; L.fillRect(0, 0, W, H);
      L.globalCompositeOperation = 'destination-out';
      const pools = [];
      if (lampsOn > 0.01) for (const [lx, ly] of this.lamps) {
        const dx = lx - cx, dy = ly - cy, z = dx * fwx + dy * fwy; if (z < 10 || z > far * 0.85) continue;
        const sx = X(dx, dy, z); if (sx < -W * 0.6 || sx > W * 1.6) continue;
        const rw = f * 190 / z, rh = Math.max(2, f * camH * 190 / (z * z)), by = gy(z); pools.push([sx, by, rw, rh, z]);
        L.save(); L.translate(sx, by); L.scale(1, rh / rw); const gr = L.createRadialGradient(0, 0, 0, 0, 0, rw); gr.addColorStop(0, `rgba(0,0,0,${0.95 * lampsOn})`); gr.addColorStop(0.5, `rgba(0,0,0,${0.5 * lampsOn})`); gr.addColorStop(1, 'rgba(0,0,0,0)'); L.fillStyle = gr; L.beginPath(); L.arc(0, 0, rw, 0, 7); L.fill(); L.restore();
        const hy = hor + f * (camH - 30) / z, hr = Math.max(3, f * 40 / z), hg = L.createRadialGradient(sx, hy, 0, sx, hy, hr); hg.addColorStop(0, `rgba(0,0,0,${0.8 * lampsOn})`); hg.addColorStop(1, 'rgba(0,0,0,0)'); L.fillStyle = hg; L.fillRect(sx - hr, hy - hr, hr * 2, hr * 2);
      }
      if (!this.tc || this.tc.width !== W || this.tc.height !== H) { this.tc = document.createElement('canvas'); this.tc.width = W; this.tc.height = H; this.T = this.tc.getContext('2d'); }
      const coneRaw = (ctx, rgb, a) => {
        const ch = Math.cos(c.h), sh = Math.sin(c.h), ox = c.x + ch * 18, oy = c.y + sh * 18, P = (d, l) => { const wx = ox + ch * d - sh * l - cx, wy = oy + sh * d + ch * l - cy, z = wx * fwx + wy * fwy; return z > 3 ? [X(wx, wy, z), gy(z)] : null; };
        const n1 = P(0, -6), n2 = P(0, 6), f1 = P(380, -150), f2 = P(380, 150), mid = P(220, 0); if (!n1 || !n2 || !f1 || !f2 || !mid) return;
        const gr = ctx.createLinearGradient(n1[0], n1[1], mid[0], mid[1] - 0.001); gr.addColorStop(0, `rgba(${rgb},${a})`); gr.addColorStop(1, `rgba(${rgb},0)`);
        ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(n1[0], n1[1]); ctx.lineTo(f1[0], f1[1]); ctx.lineTo(f2[0], f2[1]); ctx.lineTo(n2[0], n2[1]); ctx.closePath(); ctx.fill();
      };
      // the beam is drawn on a scratch layer, the car's silhouette is erased from it, then it is applied: the car always sits OVER the light
      const cone = (ctx, rgb, a) => {
        const T = this.T; T.setTransform(1, 0, 0, 1, 0, 0); T.globalCompositeOperation = 'source-over'; T.clearRect(0, 0, W, H); coneRaw(T, rgb, a);
        const cp = this.carPose; if (cp) { T.globalCompositeOperation = 'destination-out'; T.globalAlpha = 1; T.save(); T.translate(cp.sx, cp.b); T.rotate(cp.rot); T.drawImage(cp.spr, -cp.w / 2, -cp.h, cp.w, cp.h); T.restore(); T.globalAlpha = 1; T.globalCompositeOperation = 'source-over'; }
        ctx.drawImage(this.tc, 0, 0);
      };
      if (headOn > 0.01) { const car0 = [X(c.x - cx, c.y - cy, (c.x - cx) * fwx + (c.y - cy) * fwy), gy((c.x - cx) * fwx + (c.y - cy) * fwy)]; const cg = L.createRadialGradient(car0[0], car0[1], 0, car0[0], car0[1], f * 40 / cd); cg.addColorStop(0, `rgba(0,0,0,${0.85 * headOn})`); cg.addColorStop(1, 'rgba(0,0,0,0)'); L.fillStyle = cg; L.fillRect(car0[0] - f * 40 / cd, car0[1] - f * 40 / cd, f * 80 / cd, f * 80 / cd); cone(L, '0,0,0', 0.97 * headOn); }
      g.drawImage(this.lc, 0, 0);
      g.globalCompositeOperation = 'lighter';
      for (const [sx, by, rw, rh] of pools) { g.save(); g.translate(sx, by); g.scale(1, rh / rw); const gr = g.createRadialGradient(0, 0, 0, 0, 0, rw * 0.8); gr.addColorStop(0, `rgba(255,214,140,${0.28 * lampsOn})`); gr.addColorStop(1, 'rgba(255,190,100,0)'); g.fillStyle = gr; g.beginPath(); g.arc(0, 0, rw * 0.8, 0, 7); g.fill(); g.restore(); }
      if (headOn > 0.01) cone(g, '255,244,205', 0.28 * headOn);
      g.globalCompositeOperation = 'source-over';
    }

    /* rain, vignette, crash flash */
    if (ENV.rain > 0.03) {
      g.strokeStyle = `rgba(210,225,255,${0.25 + 0.2 * ENV.rain})`; g.lineWidth = 1; g.beginPath();
      const n = Math.floor(this.drops.length * ENV.rain), L2 = 5 + H / 60;
      for (let i = 0; i < n; i++) { const d = this.drops[i]; d.y += d.v * dt * 1.5; d.x -= d.v * dt * 0.2; if (d.y > 1) { d.y = -0.05; d.x = Math.random() * 1.2; } if (d.x < -0.1) d.x += 1.2; const x = d.x * W, y = d.y * H; g.moveTo(x, y); g.lineTo(x - L2 * 0.25, y + L2); }
      g.stroke();
    }
    if (!this.vig || this.vig.width !== W) { const v = document.createElement('canvas'); v.width = W; v.height = H; const vg = v.getContext('2d'), gr = vg.createRadialGradient(W / 2, H * 0.55, H * 0.45, W / 2, H * 0.55, H * 1.05); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.38)'); vg.fillStyle = gr; vg.fillRect(0, 0, W, H); this.vig = v; }
    g.drawImage(this.vig, 0, 0);
    if (this.flash > 0.01) { g.fillStyle = `rgba(255,50,30,${this.flash * 0.5})`; g.fillRect(0, 0, W, H); }
    return { sx: (Math.random() - 0.5) * this.shake * 8, sy: (Math.random() - 0.5) * this.shake * 8 };
  }

  treesOf(tx, ty) {
    const key = ty * 4096 + tx; let a = this.treeMap.get(key);
    if (a) return a;
    a = []; if (tx >= 0 && ty >= 0) {
      const R = rng32((tx * 73856093) ^ (ty * 19349663) ^ 991);
      for (let n = 0; n < 34; n++) { const x = (tx + R()) * TS, y = (ty + R()) * TS, h = 34 + R() * 54, v = (R() * 4) | 0; if (!this.tr.nearRoad(x, y)) a.push([x, y, h, v]); }
    }
    this.treeMap.set(key, a); if (this.treeMap.size > 400) this.treeMap.delete(this.treeMap.keys().next().value);
    return a;
  }
}
