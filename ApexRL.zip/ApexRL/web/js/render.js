/* Procedural art, rendered in cached tiles so a 20 km track stays fast: grass, asphalt, kerbs, tyre walls, trees, start grid.
   Car sprite comes from assets/car.png (drop your own image there). */
const CAR_IMG = { src: 'assets/car.png', lights: 'assets/car_lights.png', facing: 'left', length: 46 };   // facing: which way the nose points in the PNG: left | right | up | down
let carSprite = null, carLights = null;   // assets/car.png (day) and assets/car_lights.png (night / rain, headlights on)

function loadCarSprite() {
  const load = (src) => new Promise(res => { const im = new Image(); im.onload = () => res(im); im.onerror = () => res(null); im.src = src + '?v=' + Date.now(); });
  Promise.all([load(CAR_IMG.src), load(CAR_IMG.lights)]).then(([day, lit]) => {
    carSprite = day ? prepSprite(day) : null;
    // the lights sprite is cropped exactly like the day sprite (when same size), so both line up even if the glow spills past the car
    carLights = lit ? prepSprite(lit, carSprite && day.naturalWidth === lit.naturalWidth && day.naturalHeight === lit.naturalHeight ? carSprite.frac : null) : null;
  });
}

// Makes a white / plain background transparent (flood fill from the edges) and crops to the car.
function prepSprite(im, frac) {
  const w = Math.min(im.naturalWidth, 640), h = Math.round(im.naturalHeight * w / im.naturalWidth);
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(im, 0, 0, w, h);
  const d = x.getImageData(0, 0, w, h), a = d.data;
  const white = i => a[i + 3] > 200 && a[i] > 232 && a[i + 1] > 232 && a[i + 2] > 232;
  if (white(0)) {
    const seen = new Uint8Array(w * h), st = new Int32Array(w * h); let sp = 0;
    const push = (px, py) => { if (px < 0 || py < 0 || px >= w || py >= h) return; const k = py * w + px; if (!seen[k] && white(k * 4)) { seen[k] = 1; st[sp++] = k; } };
    for (let i = 0; i < w; i++) { push(i, 0); push(i, h - 1); }
    for (let j = 0; j < h; j++) { push(0, j); push(w - 1, j); }
    while (sp) { const k = st[--sp]; a[k * 4 + 3] = 0; const px = k % w, py = (k / w) | 0; push(px + 1, py); push(px - 1, py); push(px, py + 1); push(px, py - 1); }
    x.putImageData(d, 0, 0);
  }
  let x0 = w, y0 = h, x1 = 0, y1 = 0;
  if (frac) { x0 = Math.round(frac[0] * w); y0 = Math.round(frac[1] * h); x1 = Math.round(frac[2] * w) - 1; y1 = Math.round(frac[3] * h) - 1; }
  else for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) if (a[(j * w + i) * 4 + 3] > 12) { if (i < x0) x0 = i; if (i > x1) x1 = i; if (j < y0) y0 = j; if (j > y1) y1 = j; }
  if (x1 <= x0) return c;
  const o = document.createElement('canvas'); o.width = x1 - x0 + 1; o.height = y1 - y0 + 1;
  o.getContext('2d').drawImage(c, x0, y0, o.width, o.height, 0, 0, o.width, o.height);
  o.frac = [x0 / w, y0 / h, (x1 + 1) / w, (y1 + 1) / h];
  return o;
}

/* Optional art for the 3D view / ground. Every file is optional: missing ones fall back to generated art. */
const art3d = { back: null, backLights: null, left: null, right: null, trees: [], skyDay: null, skyNight: null, grass: null, asphalt: null };
function loadArt3D() {
  const load = src => new Promise(res => { const im = new Image(); im.onload = () => res(im); im.onerror = () => res(null); im.src = src + '?v=' + Date.now(); });
  const tex = im => { if (!im) return null; const c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight; c.getContext('2d').drawImage(im, 0, 0); c._k = 192 / im.naturalWidth; return c; };
  const spr = im => (im ? prepSprite(im) : null);
  const manifest = fetch('/api/assets').then(r => r.json()).catch(() => null);      // only request files that exist (no 404 noise)
  const names = ['car_back', 'car_back_lights', 'car_back_left', 'car_back_right', 'tree_1', 'tree_2', 'tree_3', 'tree_4', 'sky_day', 'sky_night', 'grass', 'asphalt'];
  return manifest.then(have => Promise.all(names.map(n => (have && !have.includes(n + '.png') ? Promise.resolve(null) : load('assets/' + n + '.png'))))).then(([b, bl, l, r, t1, t2, t3, t4, sd, sn, gr, as]) => {
    art3d.back = spr(b); art3d.backLights = spr(bl); art3d.left = spr(l); art3d.right = spr(r);
    art3d.trees = [t1, t2, t3, t4].filter(Boolean).map(spr);
    art3d.skyDay = sd; art3d.skyNight = sn; art3d.grass = tex(gr); art3d.asphalt = tex(as);
  });
}

const FACE = { left: Math.PI, right: 0, up: -Math.PI / 2, down: Math.PI / 2 };

function spriteDraw(g, sp, alpha) {
  const vertical = CAR_IMG.facing === 'up' || CAR_IMG.facing === 'down';
  const len = vertical ? sp.height : sp.width, k = CAR_IMG.length / len;
  g.globalAlpha = alpha; g.save(); g.rotate(FACE[CAR_IMG.facing] ?? Math.PI);
  g.drawImage(sp, -sp.width * k / 2, -sp.height * k / 2, sp.width * k, sp.height * k); g.restore();
}

// mix = 0..1: how much the headlights-on sprite replaces the day sprite
function drawCar(g, x, y, h, alpha = 1, mix = 0) {
  g.save(); g.translate(x, y); g.rotate(h);
  if (carSprite) {
    const vertical = CAR_IMG.facing === 'up' || CAR_IMG.facing === 'down', wid = (vertical ? carSprite.width : carSprite.height) * CAR_IMG.length / (vertical ? carSprite.height : carSprite.width);
    g.globalAlpha = alpha; g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.ellipse(2, 3, CAR_IMG.length * 0.5, wid * 0.55, 0, 0, 7); g.fill();
    if (carLights && mix > 0.01) { spriteDraw(g, carSprite, alpha * (1 - mix)); spriteDraw(g, carLights, alpha * mix); }
    else spriteDraw(g, carSprite, alpha);
  } else {                                           // fallback if assets/car.png is missing
    g.globalAlpha = alpha; g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(2, 3, 22, 11, 0, 0, 7); g.fill();
    g.fillStyle = '#16171a';
    for (const [wx, wy] of [[12, -10], [12, 10], [-12, -10], [-12, 10]]) g.fillRect(wx - 5, wy - 3, 10, 6);
    g.fillStyle = '#35c2ff'; g.beginPath(); g.moveTo(21, 0); g.lineTo(10, -4); g.lineTo(-3, -7); g.lineTo(-17, -5.5); g.lineTo(-17, 5.5); g.lineTo(-3, 7); g.lineTo(10, 4); g.closePath(); g.fill();
    g.fillStyle = '#0d0e10'; g.beginPath(); g.ellipse(-1, 0, 5, 3.6, 0, 0, 7); g.fill();
  }
  if (mix > 0.01 && !carLights) {                    // no car_lights.png yet: draw simple glowing headlights on the normal sprite
    g.globalCompositeOperation = 'lighter'; g.globalAlpha = mix;
    for (const sy of [-6.5, 6.5]) { const gr = g.createRadialGradient(CAR_IMG.length * 0.48, sy, 0, CAR_IMG.length * 0.48, sy, 11); gr.addColorStop(0, 'rgba(255,250,215,1)'); gr.addColorStop(1, 'rgba(255,230,150,0)'); g.fillStyle = gr; g.fillRect(CAR_IMG.length * 0.48 - 12, sy - 12, 24, 24); }
  }
  g.restore();
}

function noiseTile(base, amp, dots, size, blobs) {
  const c = document.createElement('canvas'); c.width = c.height = size;
  const g = c.getContext('2d');
  g.fillStyle = `rgb(${base})`; g.fillRect(0, 0, size, size);
  for (let i = 0; i < blobs; i++) {
    const l = (Math.random() - 0.5) * amp * 1.4;
    g.fillStyle = `rgba(${base.map(v => clamp(v + l, 0, 255)).join(',')},.12)`;
    g.beginPath(); g.arc(Math.random() * size, Math.random() * size, 10 + Math.random() * 26, 0, 7); g.fill();
  }
  for (let i = 0; i < dots; i++) {
    const l = (Math.random() - 0.5) * amp;
    g.fillStyle = `rgb(${base.map(v => clamp(v + l, 0, 255)).join(',')})`;
    g.fillRect(Math.random() * size, Math.random() * size, 1 + Math.random() * 2, 1 + Math.random() * 2);
  }
  return c;
}

const TS = 384, TSC = 2;     // tile = 384 world px, rendered at 2x

class TileCache {
  constructor(tr, opts = {}) {
    this.tr = tr; this.map = new Map(); this.flat = !!opts.flat; this.sc = opts.scale || TSC;      // flat = ground only (no trees / walls), used by the 3D view
    this.rough = art3d.grass || noiseTile([46, 104, 46], 30, 14000, 384, 60);
    this.mown = art3d.grass || noiseTile([66, 138, 56], 26, 14000, 384, 60);
    this.asph = art3d.asphalt || noiseTile([57, 60, 68], 16, 9000, 384, 20);
  }

  get(tx, ty, allowBuild) {
    const key = ty * 4096 + tx;
    let t = this.map.get(key);
    if (t) { this.map.delete(key); this.map.set(key, t); return t; }
    if (!allowBuild) return null;
    t = this.build(tx, ty); this.map.set(key, t);
    if (this.map.size > 60) this.map.delete(this.map.keys().next().value);
    return t;
  }

  // Top-down tile for the 3D-model track: variable-width asphalt, the grass strip, and the real walls where the model has them.
  buildGLB(tx, ty) {
    const tr = this.tr, { xs, ys, nx, ny, M } = tr;
    const c = document.createElement('canvas'); c.width = c.height = TS * this.sc;
    const g = c.getContext('2d');
    g.scale(this.sc, this.sc); g.translate(-tx * TS, -ty * TS);
    const pat = (img) => { const p = g.createPattern(img, 'repeat'); const k = img._k || 0.5; p.setTransform(new DOMMatrix([k, 0, 0, k, 0, 0])); return p; };
    const x0 = tx * TS, y0 = ty * TS, m = 140;
    const runs = []; let cur = null;
    for (let i = 0; i <= M; i++) {
      const j = i % M, inb = xs[j] > x0 - m && xs[j] < x0 + TS + m && ys[j] > y0 - m && ys[j] < y0 + TS + m;
      if (inb) { if (!cur) { cur = []; runs.push(cur); } cur.push(i); } else cur = null;
    }
    const pt = (i, o) => { const j = i % M; return [xs[j] + nx[j] * o, ys[j] + ny[j] * o]; };
    const polygon = (r, offL, offR, fill) => {                    // ribbon between left offset offL(i) and right offset -offR(i)
      g.beginPath();
      r.forEach((i, k) => { const p = pt(i, offL(i % M)); k ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); });
      for (let k = r.length - 1; k >= 0; k--) { const p = pt(r[k], -offR(r[k] % M)); g.lineTo(p[0], p[1]); }
      g.closePath(); g.fillStyle = fill; g.fill();
    };
    g.fillStyle = pat(this.rough); g.fillRect(x0 - 2, y0 - 2, TS + 4, TS + 4);
    const mown = pat(this.mown);
    for (const r of runs) polygon(r, i => tr.bndL[i] + 26, i => tr.bndR[i] + 26, 'rgba(60,110,50,.55)');   // lighter ground near the road
    for (const r of runs) polygon(r, i => tr.bndL[i], i => tr.bndR[i], mown);                                 // the strip between asphalt and wall
    if (!this.flat) for (const side of [1, -1]) {                                                            // real walls (armco / tyres): only where the model has them
      const flag = side > 0 ? tr.wallL : tr.wallR, bnd = side > 0 ? tr.bndL : tr.bndR;
      for (const r of runs) {
        let open = false;
        const stroke = () => { g.strokeStyle = '#d9dbe0'; g.lineWidth = 2.6; g.stroke(); g.strokeStyle = '#4a4e57'; g.lineWidth = 1; g.stroke(); open = false; };
        for (const i of r) {
          const j = i % M;
          if (flag[j]) { const p = pt(i, side * (bnd[j] + 1)); if (!open) { g.beginPath(); g.moveTo(p[0], p[1]); open = true; } else g.lineTo(p[0], p[1]); }
          else if (open) stroke();
        }
        if (open) stroke();
      }
    }
    g.save(); g.translate(1.5, 2); for (const r of runs) polygon(r, i => tr.roadL[i] + 1, i => tr.roadR[i] + 1, 'rgba(0,0,0,.3)'); g.restore();
    for (const r of runs) polygon(r, i => tr.roadL[i], i => tr.roadR[i], pat(this.asph));                    // asphalt
    for (const s of [1, -1]) for (const r of runs) {                                                         // white edge lines
      g.beginPath(); r.forEach((i, k) => { const j = i % M, p = pt(i, s * ((s > 0 ? tr.roadL[j] : tr.roadR[j]) - 1.6)); k ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); });
      g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = 0.9; g.stroke();
    }
    g.lineWidth = 0.8; g.setLineDash([6, 12]); g.strokeStyle = 'rgba(255,255,255,.35)';
    for (const r of runs) { g.beginPath(); r.forEach((i, k) => { const p = pt(i, 0); k ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); }); g.stroke(); }
    g.setLineDash([]);
    if (Math.hypot(xs[0] - (x0 + TS / 2), ys[0] - (y0 + TS / 2)) < TS) {                                     // start / finish line
      g.save(); g.translate(xs[0], ys[0]); g.rotate(Math.atan2(tr.ty[0], tr.tx[0]));
      const sq = 2.4, n = Math.floor(tr.roadL[0] / sq);
      for (let r = 0; r < 2; r++) for (let q = -n; q < n; q++) { g.fillStyle = (r + q) & 1 ? '#f4f4f4' : '#15161a'; g.fillRect(-sq + r * sq, q * sq, sq, sq); }
      g.restore();
    }
    return c;
  }

  build(tx, ty) {
    if (this.tr.glb) return this.buildGLB(tx, ty);
    const tr = this.tr, { xs, ys, nx, ny, M, hw, kerb } = tr;
    const c = document.createElement('canvas'); c.width = c.height = TS * this.sc;
    const g = c.getContext('2d');
    g.scale(this.sc, this.sc); g.translate(-tx * TS, -ty * TS);
    const pat = (img) => { const p = g.createPattern(img, 'repeat'); const k = img._k || 0.5; p.setTransform(new DOMMatrix([k, 0, 0, k, 0, 0])); return p; };
    const x0 = tx * TS, y0 = ty * TS, m = hw + kerb + 170;

    const runs = []; let cur = null;
    for (let i = 0; i <= M; i++) {
      const j = i % M, inb = xs[j] > x0 - m && xs[j] < x0 + TS + m && ys[j] > y0 - m && ys[j] < y0 + TS + m;
      if (inb) { if (!cur) { cur = []; runs.push(cur); } cur.push(i); } else cur = null;
    }
    const pt = (i, o) => { const j = i % M; return [xs[j] + nx[j] * o, ys[j] + ny[j] * o]; };
    const strokeRuns = (w, style, off = 0, cap = 'round') => {
      g.lineWidth = w; g.strokeStyle = style; g.lineCap = cap; g.lineJoin = 'round';
      for (const r of runs) { g.beginPath(); r.forEach((i, k) => { const p = pt(i, off); k ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); }); g.stroke(); }
    };
    const strokeGroups = (w, n, styleFn) => {            // absolute-index groups => patterns line up across tiles
      g.lineWidth = w; g.lineCap = 'butt'; g.lineJoin = 'round';
      for (const r of runs) {
        let gk = null, style = null;
        for (const i of r) {
          const k = Math.floor(i / n), p = pt(i, 0);
          if (k !== gk) {
            if (gk !== null) { g.lineTo(p[0], p[1]); if (style) { g.strokeStyle = style; g.stroke(); } }
            g.beginPath(); g.moveTo(p[0], p[1]); gk = k; style = styleFn(k);
          } else g.lineTo(p[0], p[1]);
        }
        if (style) { g.strokeStyle = style; g.stroke(); }
      }
    };

    g.fillStyle = pat(this.rough); g.fillRect(x0 - 2, y0 - 2, TS + 4, TS + 4);
    const mown = pat(this.mown);
    for (const [w, a] of [[hw + 150, 0.35], [hw + 112, 0.55], [hw + 80, 1]]) { g.globalAlpha = a; strokeRuns(2 * w, mown); }
    g.globalAlpha = 1;

    if (!this.flat) for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {      // trees, deterministic per tile
      const R = rng32(((tx + dx) * 92821) ^ ((ty + dy) * 68917) ^ 777);
      for (let n = 0; n < 7; n++) {
        const px = (tx + dx + R()) * TS, py = (ty + dy + R()) * TS, rad = 14 + R() * 16;
        if (tr.nearRoad(px, py)) continue;
        g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.ellipse(px + 7, py + 9, rad, rad * 0.9, 0, 0, 7); g.fill();
        g.fillStyle = '#1f4a26'; g.beginPath(); g.arc(px, py, rad, 0, 7); g.fill();
        g.fillStyle = '#2d6a35'; g.beginPath(); g.arc(px - rad * .2, py - rad * .2, rad * .72, 0, 7); g.fill();
        g.fillStyle = '#4a9a4a'; g.beginPath(); g.arc(px - rad * .35, py - rad * .35, rad * .35, 0, 7); g.fill();
      }
    }

    g.save(); g.translate(3, 4); strokeRuns(2 * (hw + kerb + 5), 'rgba(0,0,0,.35)'); g.restore();
    strokeGroups(2 * (hw + kerb), 3, k => (k & 1 ? '#f4f4f4' : '#d4202a'));                  // kerbs
    if (!this.flat) for (const s of [1, -1]) {                                                // armco + tyre wall
      strokeRuns(5, '#d9dbe0', s * (hw + kerb + 4), 'butt'); strokeRuns(2, '#7d818b', s * (hw + kerb + 7), 'butt');
      for (const r of runs) for (const i of r) {
        if (i % 3) continue;
        const p = pt(i, s * (hw + kerb + 13));
        g.fillStyle = '#17181b'; g.beginPath(); g.arc(p[0], p[1], 6, 0, 7); g.fill();
        g.strokeStyle = (i / 3) % 6 < 3 ? '#f2f2f2' : '#d4202a'; g.lineWidth = 1.6; g.stroke();
      }
    }
    strokeRuns(2 * hw, pat(this.asph));                                                      // asphalt
    for (const s of [1, -1]) strokeRuns(2.5, 'rgba(255,255,255,.85)', s * (hw - 6), 'butt');
    strokeGroups(2, 4, k => (k % 3 === 0 ? 'rgba(255,255,255,.3)' : null));                 // centre dashes

    if (Math.hypot(xs[0] - (x0 + TS / 2), ys[0] - (y0 + TS / 2)) < TS) {                     // start / finish
      g.save(); g.translate(xs[0], ys[0]); g.rotate(Math.atan2(tr.ty[0], tr.tx[0]));
      const sq = 8, n = Math.floor(hw / sq);
      for (let r = 0; r < 2; r++) for (let q = -n; q < n; q++) { g.fillStyle = (r + q) & 1 ? '#f4f4f4' : '#15161a'; g.fillRect(-sq + r * sq, q * sq, sq, sq); }
      g.restore();
    }
    return c;
  }
}

/* Whole-track overview for the minimap / full map */
function buildOverview(tr) {
  const W = 1500, sc = W / tr.WW, H = Math.ceil(tr.WH * sc);
  const base = document.createElement('canvas'); base.width = W; base.height = H;
  const g = base.getContext('2d');
  g.fillStyle = '#16301a'; g.fillRect(0, 0, W, H);
  const path = upto => { g.beginPath(); for (let i = 0; i <= upto; i++) { const j = i % tr.M; i ? g.lineTo(tr.xs[j] * sc, tr.ys[j] * sc) : g.moveTo(tr.xs[j] * sc, tr.ys[j] * sc); } };
  g.lineJoin = g.lineCap = 'round';
  const w = Math.max(5, 2 * (tr.hw + tr.kerb) * sc);
  path(tr.M); g.strokeStyle = '#f0f0f2'; g.lineWidth = w + 3; g.stroke();
  path(tr.M); g.strokeStyle = '#4b505b'; g.lineWidth = w; g.stroke();
  const cache = document.createElement('canvas'); cache.width = W; cache.height = H;
  const ov = { base, cache, sc, W, H, drawnTo: -1 };
  refreshOverview(ov, tr, 0);
  return ov;
}

function refreshOverview(ov, tr, upto) {            // green = how far the car has ever got
  if (upto === ov.drawnTo) return;
  ov.drawnTo = upto;
  const g = ov.cache.getContext('2d'), sc = ov.sc;
  g.clearRect(0, 0, ov.W, ov.H); g.drawImage(ov.base, 0, 0);
  if (upto > 1) {
    g.beginPath(); for (let i = 0; i <= upto; i++) { const j = i % tr.M; i ? g.lineTo(tr.xs[j] * sc, tr.ys[j] * sc) : g.moveTo(tr.xs[j] * sc, tr.ys[j] * sc); }
    g.lineJoin = g.lineCap = 'round'; g.strokeStyle = '#4be0a0'; g.lineWidth = Math.max(3, 2 * tr.hw * sc * 0.55); g.stroke();
  }
  g.fillStyle = '#fff'; g.beginPath(); g.arc(tr.xs[0] * sc, tr.ys[0] * sc, 5, 0, 7); g.fill();
}


/* ---------- lamp posts, night lighting, rain ---------- */
function buildLamps(tr) {
  const lamps = [], off = tr.hw + tr.kerb + 24;
  for (let i = 0, k = 0; i < tr.M; i += 26, k++) { const side = k % 2 ? 1 : -1; lamps.push([tr.xs[i] + tr.nx[i] * off * side, tr.ys[i] + tr.ny[i] * off * side]); }
  return lamps;
}

class Lighting {
  constructor() { this.cv = document.createElement('canvas'); this.g = this.cv.getContext('2d'); this.scale = 0.5; }
  resize(vw, vh, dpr) { this.cv.width = Math.ceil(vw * dpr * this.scale); this.cv.height = Math.ceil(vh * dpr * this.scale); }

  // world transform: screen = DPR * (zoom * (p - cam) + V/2)
  draw(g, o) {
    const { lamps, car, zoom, camX, camY, VW, VH, DPR } = o, L = this.g, S = DPR * this.scale;
    const dark = clamp(0.86 * ENV.night + 0.22 * ENV.rain * (1 - ENV.night), 0, 0.9), lampsOn = clamp((ENV.night - 0.25) / 0.5, 0, 1), headOn = Math.max(clamp((ENV.night - 0.25) / 0.5, 0, 1), clamp((ENV.rain - 0.45) / 0.4, 0, 1));
    if (ENV.rain > 0.02) { g.setTransform(DPR, 0, 0, DPR, 0, 0); g.fillStyle = `rgba(35,48,66,${0.26 * ENV.rain})`; g.fillRect(0, 0, VW, VH); }   // overcast tint
    if (dark < 0.02) return;
    L.globalCompositeOperation = 'source-over'; L.setTransform(1, 0, 0, 1, 0, 0); L.clearRect(0, 0, this.cv.width, this.cv.height);
    L.fillStyle = `rgba(3,7,20,${dark})`; L.fillRect(0, 0, this.cv.width, this.cv.height);
    L.setTransform(S * zoom, 0, 0, S * zoom, S * (VW / 2 - camX * zoom), S * (VH / 2 - camY * zoom));
    L.globalCompositeOperation = 'destination-out';
    const vx0 = camX - VW / 2 / zoom - 220, vx1 = camX + VW / 2 / zoom + 220, vy0 = camY - VH / 2 / zoom - 220, vy1 = camY + VH / 2 / zoom + 220;
    const lampPass = (ctx, strength, colorFn) => {
      for (const [lx, ly] of lamps) {
        if (lx < vx0 || lx > vx1 || ly < vy0 || ly > vy1) continue;
        const gr = ctx.createRadialGradient(lx, ly, 0, lx, ly, 175); colorFn(gr, strength);
        ctx.fillStyle = gr; ctx.fillRect(lx - 175, ly - 175, 350, 350);
      }
    };
    if (lampsOn > 0.01) lampPass(L, lampsOn, (gr, k) => { gr.addColorStop(0, `rgba(0,0,0,${0.95 * k})`); gr.addColorStop(0.45, `rgba(0,0,0,${0.55 * k})`); gr.addColorStop(1, 'rgba(0,0,0,0)'); });
    const hx = car.x + Math.cos(car.h) * CL * 0.5, hy = car.y + Math.sin(car.h) * CL * 0.5, glow = (ctx, a) => { const gr = ctx.createRadialGradient(car.x, car.y, 0, car.x, car.y, 90); gr.addColorStop(0, `rgba(0,0,0,${a})`); gr.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = gr; ctx.fillRect(car.x - 90, car.y - 90, 180, 180); };
    const cone = (ctx, rgb, a) => {
      ctx.save(); ctx.translate(hx, hy); ctx.rotate(car.h);
      const len = 340, w = Math.tan(0.36) * len, gr = ctx.createLinearGradient(0, 0, len, 0);
      gr.addColorStop(0, `rgba(${rgb},${a})`); gr.addColorStop(0.55, `rgba(${rgb},${a * 0.45})`); gr.addColorStop(1, `rgba(${rgb},0)`);
      ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(0, -6); ctx.lineTo(len, -w); ctx.lineTo(len, w); ctx.lineTo(0, 6); ctx.closePath(); ctx.fill(); ctx.restore();
    };
    if (headOn > 0.01) { glow(L, 0.9 * headOn); cone(L, '0,0,0', 0.97 * headOn); }
    g.setTransform(DPR, 0, 0, DPR, 0, 0); g.globalCompositeOperation = 'source-over'; g.drawImage(this.cv, 0, 0, VW, VH);
    // warm additive glow on top
    g.setTransform(DPR * zoom, 0, 0, DPR * zoom, DPR * (VW / 2 - camX * zoom), DPR * (VH / 2 - camY * zoom));
    g.globalCompositeOperation = 'lighter';
    if (lampsOn > 0.01) lampPass(g, lampsOn, (gr, k) => { gr.addColorStop(0, `rgba(255,214,140,${0.30 * k})`); gr.addColorStop(1, 'rgba(255,190,100,0)'); });
    if (headOn > 0.01) cone(g, '255,244,205', 0.30 * headOn);
    g.globalCompositeOperation = 'source-over';
  }
}

function drawLampPosts(g, lamps, vx0, vx1, vy0, vy1) {
  const on = clamp((ENV.night - 0.25) / 0.5, 0, 1);
  for (const [x, y] of lamps) {
    if (x < vx0 || x > vx1 || y < vy0 || y > vy1) continue;
    g.fillStyle = '#2a2d34'; g.beginPath(); g.arc(x, y, 3.2, 0, 7); g.fill();
    g.fillStyle = on > 0.1 ? `rgba(255,236,170,${0.5 + 0.5 * on})` : '#9aa0aa'; g.beginPath(); g.arc(x, y, 2, 0, 7); g.fill();
  }
}

class Rain {
  constructor() { this.d = Array.from({ length: 420 }, () => ({ x: Math.random(), y: Math.random(), v: 0.9 + Math.random() * 0.8, l: 10 + Math.random() * 16 })); }
  draw(g, VW, VH, DPR, dt) {
    if (ENV.rain < 0.03) return;
    const n = Math.floor(this.d.length * ENV.rain);
    g.setTransform(DPR, 0, 0, DPR, 0, 0); g.strokeStyle = `rgba(205,225,255,${0.2 + 0.25 * ENV.rain})`; g.lineWidth = 1.2; g.beginPath();
    for (let i = 0; i < n; i++) {
      const p = this.d[i]; p.y += p.v * dt * 1.5; p.x -= p.v * dt * 0.22;
      if (p.y > 1) { p.y = -0.05; p.x = Math.random() * 1.2; } if (p.x < -0.1) p.x += 1.2;
      const x = p.x * VW, y = p.y * VH; g.moveTo(x, y); g.lineTo(x - p.l * 0.2, y + p.l);
    }
    g.stroke();
  }
}

class Spray {                                         // water thrown up behind the car on a wet road
  constructor() { this.p = []; }
  update(car, dt) {
    const sp = Math.min(1, car.v / 120) * ENV.wet;
    if (sp > 0.05) for (const s of [-1, 1]) if (Math.random() < sp) {
      const bx = car.x - Math.cos(car.h) * CL * 0.45 - Math.sin(car.h) * s * CW * 0.45, by = car.y - Math.sin(car.h) * CL * 0.45 + Math.cos(car.h) * s * CW * 0.45;
      this.p.push({ x: bx, y: by, vx: -Math.cos(car.vang) * car.v * 0.25 + (Math.random() - 0.5) * 30, vy: -Math.sin(car.vang) * car.v * 0.25 + (Math.random() - 0.5) * 30, life: 0.7 });
    }
    for (const q of this.p) { q.x += q.vx * dt; q.y += q.vy * dt; q.life -= dt; }
    this.p = this.p.filter(q => q.life > 0).slice(-90);
  }
  draw(g) { for (const q of this.p) { g.fillStyle = `rgba(225,235,250,${q.life * 0.35})`; g.beginPath(); g.arc(q.x, q.y, 3 + (0.7 - q.life) * 9, 0, 7); g.fill(); } }
}
