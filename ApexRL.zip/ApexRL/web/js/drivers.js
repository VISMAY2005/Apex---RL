/* Reference drivers (real published Nordschleife lap times), a "teacher" driver for imitation learning, and the ghost pace profile.
   Times verified against: nuerburgring.de, evo.co.uk, gtspirit.com, autoexpress.co.uk, autocar.co.uk, fastestlaps.com (checked Oct 2026).
   Official laps are ~20.8 km with a flying start; the GPS trace used here is ~20.7 km, so comparisons are approximate. Times can be beaten later. */
const DRIVERS = [
  { id: 'bernhard', who: 'Timo Bernhard', car: 'Porsche 919 Hybrid Evo (LMP1)', year: 2018, t: 319.546, note: 'Outright record' },
  { id: 'idr', who: 'Volkswagen ID.R', car: 'Electric prototype', year: 2019, t: 365.33, note: 'Electric record (time as published: 6:05.33)' },
  { id: 'bellof', who: 'Stefan Bellof', car: 'Porsche 956', year: 1983, t: 371.13, note: 'Qualifying lap; stood as the record for 35 years' },
  { id: 'engel', who: 'Maro Engel', car: 'Mercedes-AMG One', year: 2024, t: 389.09, note: 'Production car record' },
  { id: 'gt2rs', who: 'Porsche 911 GT2 RS (Manthey kit)', car: 'Road car', year: 2021, t: 403.30, note: 'Time as listed on fastestlaps.com' },
  { id: 'radermecker', who: 'Vincent Radermecker', car: 'Xiaomi SU7 Ultra', year: 2025, t: 424.957, note: 'Fastest four-door EV' },
  { id: 'schwister', who: 'Tom Schwister', car: 'Tesla Model S Plaid', year: 2023, t: 445.23, note: 'Electric saloon' },
  { id: 'civic', who: 'Honda Civic Type R', car: 'Front-wheel drive', year: 2023, t: 464.88, note: 'FWD record (time as published: 7:44.88)' },
];
const fmtT = t => Math.floor(t / 60) + ':' + (t % 60).toFixed(3).padStart(6, '0');

/* Teacher driver: pure-pursuit steering + a braking/acceleration speed profile computed from the track geometry.
   It uses the track layout (privileged information), which the learner never sees. This stands in for real driver telemetry. */
class Expert {
  constructor(tr, pace = 1) {
    this.tr = tr; this.pace = pace;
    const M = tr.M, sp = tr.spacing, grip = 1 - 0.42 * ENV.wet;
    const kap = new Float64Array(M), th = new Float64Array(M);
    for (let i = 0; i < M; i++) th[i] = Math.atan2(tr.ty[i], tr.tx[i]);
    for (let i = 0; i < M; i++) {
      const a = (i - 6 + M) % M, b = (i + 6) % M;
      kap[i] = Math.abs(wrapA(th[b] - th[a])) / (12 * sp);
    }
    const sm = new Float64Array(M);
    for (let i = 0; i < M; i++) { let m = 0; for (let k = -10; k <= 10; k++) m = Math.max(m, kap[(i + k + M) % M]); sm[i] = m; }
    const aY = AY * grip * 0.7, aB = BRK * 0.72 * grip * 0.75, aA = ACC * 0.733 * (0.55 + 0.45 * grip);
    const v = new Float64Array(M);
    for (let i = 0; i < M; i++) v[i] = Math.min(MAXV * 0.97, Math.sqrt(aY / Math.max(sm[i], 1e-5)));
    for (let pass = 0; pass < 3; pass++) {
      for (let i = 2 * M - 1; i >= 0; i--) { const a = i % M, b = (i + 1) % M; v[a] = Math.min(v[a], Math.sqrt(v[b] * v[b] + 2 * aB * sp)); }
      for (let i = 0; i < 2 * M; i++) { const a = i % M, b = (i + 1) % M; v[b] = Math.min(v[b], Math.sqrt(v[a] * v[a] + 2 * aA * sp)); }
    }
    this.vprof = v;
  }
  lapTime() { let t = 0; for (let i = 0; i < this.tr.M; i++) t += this.tr.spacing / this.vprof[i]; return t; }

  act(car) {
    const tr = this.tr, M = tr.M, sp = tr.spacing, i = car.idx;
    const Ld = 28 + 0.55 * car.v, j = (i + Math.ceil(Ld / sp)) % M;
    const al = wrapA(Math.atan2(tr.ys[j] - car.y, tr.xs[j] - car.x) - car.h);
    const ss = VSTEER ? 1 / (1 + (car.v / VSTEER) ** 2) : 1, steer = clamp(Math.atan(2 * WB * Math.sin(al) / Ld) / (MAXSTEER * ss), -1, 1);
    const vt = this.vprof[(i + Math.ceil((0.5 * car.v + 10) / sp)) % M] * this.pace;
    return [steer, clamp((vt - car.v) * 0.1, -1, 1)];
  }
}

/* Ghost pace: how long a real driver needed to reach each point of the lap (shape from the teacher's speed profile, scaled to the real lap time). */
function buildGhostClock(tr, tLap) {
  const wet = ENV.wet; ENV.wet = 0;                      // real drivers' records were set on dry tarmac
  const ex = new Expert(tr, 1); ENV.wet = wet;
  const k = ex.lapTime() / tLap, t = new Float64Array(tr.M + 1);
  for (let i = 0; i < tr.M; i++) t[i + 1] = t[i] + tr.spacing / (ex.vprof[i] * k);
  return t;                                            // t[i] = seconds from the line to sample i
}
function ghostIndexAt(t, sec) {                       // float sample index at lap-time `sec`
  let lo = 0, hi = t.length - 1;
  while (hi - lo > 1) { const m = (lo + hi) >> 1; if (t[m] <= sec) lo = m; else hi = m; }
  return lo + (sec - t[lo]) / Math.max(1e-9, t[hi] - t[lo]);
}

/* Imitation learning (behaviour cloning): the teacher drives with some deliberate wobble; the network learns "what the teacher does" from
   the sensor readings alone. The critic learns the returns. Normal reinforcement learning then continues from this head start. */
async function imitate(T, pace, onProgress) {
  const tr = T.tr, ex = new Expert(tr, pace), car = new Car(), N = 26000, data = { obs: [], act: [], ret: [] };
  const wait = () => new Promise(r => setTimeout(r, 0));
  let ep = [], noise = 0, amp = 0;
  const newEp = () => { car.reset(tr, Math.random() < 0.3 ? 0 : Math.random() * tr.lapLen * 0.98); amp = [0, 0.25, 0.5][(Math.random() * 3) | 0]; noise = 0; ep = []; if (Math.random() < 0.4) car.v = 0; };
  const flush = (terminal) => {
    let R = 0;
    for (let i = ep.length - 1; i >= 0; i--) {
      R = ep[i].r + T.hp.gamma * R;
      const reps = ep[i].o[RAYS.length] < 0.08 ? 6 : 1;               // standing starts are rare but vital: weight them up
      for (let q = 0; q < reps; q++) { data.obs.push(ep[i].o); data.act.push(ep[i].a); data.ret.push(R); }
    }
    ep = [];
  };
  newEp();
  for (let n = 0; n < N; n++) {
    const o = Float64Array.from(car.sense(tr)), a = ex.act(car);
    noise = noise * 0.96 + randn() * 0.12 * amp;
    const res = car.step(tr, [a[0] + noise, a[1]], T.hp);
    ep.push({ o, a, r: res.r });
    if (res.done) { flush(true); newEp(); }
    if (n % 1500 === 0) { onProgress && onProgress('Watching the teacher drive... ' + Math.round(n / N * 50) + '%'); await wait(); }
  }
  flush(false);
  const n = data.obs.length, idx = Array.from({ length: n }, (_, i) => i), ag = T.agent;
  for (let epoch = 0; epoch < 6; epoch++) {
    for (let i = n - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [idx[i], idx[j]] = [idx[j], idx[i]]; }
    for (let st = 0; st < n; st += 128) {
      const mb = idx.slice(st, st + 128);
      for (const i of mb) {
        const z = ag.actor.forward(data.obs[i]), dz = new Float64Array(2);
        for (let k = 0; k < 2; k++) { const mu = Math.tanh(z[k]); dz[k] = (mu - data.act[i][k]) * (1 - mu * mu); }
        ag.actor.backward(dz);
        const v = ag.critic.forward(data.obs[i])[0];
        ag.critic.backward([clamp(v - data.ret[i], -10, 10)]);
      }
      ag.actor.step(1e-3, mb.length, 1.0); ag.critic.step(2e-3, mb.length, 1.0);
      if ((st / 128) % 25 === 0) { onProgress && onProgress('Learning from the teacher... ' + Math.round(50 + (epoch + st / n) / 6 * 50) + '%'); await wait(); }
    }
  }
  ag.logStd.fill(-1.5);
  T.clearBuf(); T.respawn(); T.freezeLeft = 8;
  return n;
}
