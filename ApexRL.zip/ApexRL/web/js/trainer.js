/* Trainer: one car, real-time-style episodes. Collects rollouts -> GAE -> PPO. Also owns weather, curriculum and ghost recording. */
class Trainer {
  constructor(kind) {
    this.hp = { lr: 1.5e-4, entropy: 0, wProg: 0.06, wSpeed: 0.02, wCenter: 0.04, wSafe: 0.3, crash: 4, smart: true, gamma: 0.99, lam: 0.95, clip: 0.2, epochs: 4, mb: 256,
      randSpeed: true, anchor: true, anchorSteps: 2, adaptNoise: true, stdFloor: 0.08, stdCeil: 0.5, evalEvery: 3, rollback: true };
    this.BATCH = 1536;
    this.agent = new PPOAgent(NIN, 2);
    this.car = new Car();
    this.env = new EnvCtl();
    this.cur = { on: false, stage: 0, from: 0 };
    this.champ = {}; this.evalCar = new Car(); this.lastEval = null; this.bad = 0; this.stale = 0;
    this.manual = false; this.keys = new HumanInput(); this.demo = new DemoStore(); this.recordDemo = true; this.restartAtLine = false; this.human = { laps: 0, best: null, runs: 0 };
    this.evalMode = false; this.busy = false; this.freezeLeft = 0; this.events = []; this.trackVersion = 0;
    this.resetStats();
    this.setTrack(kind);
  }

  resetStats() {
    this.stats = { attempts: 0, crashes: 0, laps: 0, bestLap: null, bestM: 0, frontier: 0, maxReach: 0, hist: [], log: [], byCond: {}, updates: 0, steps: 0, diag: null };
    this.bestRec = null; this.cur.from = 0;
  }

  setTrack(kind) {
    this.kind = kind; setPhysics(kind === 'glb' ? 'real' : 'game'); this.tr = new Track(kind);
    this.trackVersion++; this.resetStats(); this.clearBuf(); this.respawn();
  }

  clearBuf() { this.buf = { obs: [], act: [], logp: [], val: [], rew: [], done: [] }; }

  // Mostly restart at the line; sometimes shortly before the furthest point reached, so practice goes where it is needed.
  respawn() {
    let s = 0;
    if (this.manual) {                                  // human driver: by default carry on from just before where you crashed, so every part of the track gets covered
      const c = this.car, reach = c.startPx + c.dist;
      if (!this.restartAtLine && this.humanResume > 0) s = Math.max(0, this.humanResume - 40 * PXM);
      this.car.reset(this.tr, s, s < 1 ? 0 : 45); this.rec = null; this.humanResume = 0; this.keys.clear(); return;
    }
    if (!this.evalMode && this.hp.smart && this.stats.frontier > 400 && Math.random() < 0.65)
      s = Math.max(0, this.stats.frontier - 150 - Math.random() * 1000);
    this.car.reset(this.tr, s, this.hp.randSpeed ? 60 + Math.random() * 130 : 70);   // mid-track restarts at a random speed, like a car arriving at that spot
    this.rec = s < 1 ? [] : null;                    // record laps that start from the line (for the "my best lap" ghost)
  }

  // Keep the run in progress (e.g. when you stop driving, restart, save or train) instead of losing it. No crash, so nothing is trimmed.
  flushDemo() {
    const c = this.car;
    if (!this.manual || !this.recordDemo || !this.demo.ep.obs.length) return;
    this.demo.end('open', this.hp.gamma, this.kind === 'glb' ? 'real' : 'game', Math.max(0, c.dist) / PXM, c.startPx < 1);
  }

  setManual(on) {
    if (on === this.manual) return;
    if (!on) this.flushDemo();
    this.manual = on; this.keys.clear(); this.demo.discardCurrent(); this.humanResume = 0; this.clearBuf(); this.respawn();
  }

  // One physics step with the human at the controls. Everything the AI would have seen is recorded together with what you did.
  manualTick() {
    const c = this.car, tr = this.tr;
    this.env.update(DT);
    const o = Float64Array.from(c.sense(tr)), k = this.keys.read(c.v);
    const res = c.step(tr, [k.s, k.th, k.hb], this.hp);
    this.stats.steps++;
    if (this.recordDemo) this.demo.push(o, [k.s, k.hb ? -1 : k.th], res.r);       // the AI has no handbrake output: it learns it as "brake hard"
    if (res.done) {
      const reach = c.startPx + c.dist, dM = Math.max(0, c.dist) / PXM, st = this.stats;
      if (reach > st.maxReach) st.maxReach = reach;
      const fromLine = c.startPx < 1, out = this.recordDemo ? this.demo.end(res.kind, this.hp.gamma, this.kind === 'glb' ? 'real' : 'game', dM, fromLine) : { kept: 0, dropped: 0 };
      if (res.kind === 'lap') {
        if (fromLine) { this.human.laps++; if (c.lapTime !== null && (this.human.best === null || c.lapTime < this.human.best)) this.human.best = c.lapTime; }
        this.events.push({ type: 'lap', time: c.lapTime, full: fromLine });
        this.humanResume = 0;
      } else {
        this.events.push({ type: 'crash', x: c.x, y: c.y, h: c.h, dM, kind: res.kind, manual: true, dropped: out.dropped });
        this.humanResume = reach;
      }
      this.human.runs++;
      this.respawn();
    }
  }

  tick() {
    if (this.manual) return this.manualTick();
    const c = this.car, tr = this.tr, ev = this.evalMode, b = this.buf;
    this.env.update(DT);
    const o = Float64Array.from(c.sense(tr));
    const r = this.agent.act(o, ev);
    const res = c.step(tr, r.a, this.hp);
    if (this.rec) this.rec.push(Math.round(c.x * 10) / 10, Math.round(c.y * 10) / 10, Math.round(c.h * 1000) / 1000);
    this.stats.steps++;
    if (!ev) { b.obs.push(o); b.act.push(r.a); b.logp.push(r.lp); b.val.push(r.v); b.rew.push(res.r); b.done.push(res.done ? 1 : 0); }
    if (res.done) this.endEpisode(res.kind);
    if (!ev && b.rew.length >= this.BATCH) this.update();
  }

  endEpisode(kind) {
    const s = this.stats, c = this.car, dM = Math.max(0, c.dist) / PXM, reach = c.startPx + c.dist, cond = this.env.key();
    s.attempts++;
    s.hist.push({ d: dM, line: c.startPx < 1 }); if (s.hist.length > 400) s.hist.shift();
    s.log.push([s.attempts, Math.round(dM), c.startPx < 1 ? 1 : 0, cond, kind, +(c.steps * DT).toFixed(1)]); if (s.log.length > 60000) s.log.shift();
    const bc = s.byCond[cond] || (s.byCond[cond] = { n: 0, best: 0, avg: 0 });
    bc.n++; bc.best = Math.max(bc.best, dM); bc.avg = bc.n === 1 ? dM : bc.avg * 0.9 + dM * 0.1;
    if (dM > s.bestM) s.bestM = dM;
    if (reach > s.frontier) s.frontier = reach;
    if (reach > s.maxReach) s.maxReach = reach;
    if (kind === 'lap') {
      s.frontier = 0;
      if (c.startPx < 1) {
        s.laps++;
        if (c.lapTime !== null && (s.bestLap === null || c.lapTime < s.bestLap)) { s.bestLap = c.lapTime; this.bestRec = this.rec; }
      }
      this.events.push({ type: 'lap', time: c.lapTime, full: c.startPx < 1 });
    } else {
      s.crashes++;
      this.events.push({ type: 'crash', x: c.x, y: c.y, h: c.h, dM, kind });
    }
    this.checkCurriculum();
    this.respawn();
  }

  // Auto-harder conditions: day/sunny -> night -> rain -> night rain, once recent attempts are decent.
  checkCurriculum() {
    const cu = this.cur, s = this.stats;
    if (!cu.on || cu.stage >= STAGES.length - 1) return;
    if (s.attempts - cu.from >= 30 && this.avgRecent(10) >= 0.2 * this.tr.lapLen / PXM) {
      cu.stage++; cu.from = s.attempts;
      [this.env.dayMode, this.env.weatherMode] = STAGES[cu.stage];
      this.events.push({ type: 'env', stage: cu.stage });
    }
  }

  update() {
    const { gamma, lam } = this.hp, b = this.buf, n = b.rew.length;
    let nv = b.done[n - 1] ? 0 : this.agent.value(Float64Array.from(this.car.sense(this.tr))), gae = 0;
    const adv = new Array(n), ret = new Array(n);
    for (let t = n - 1; t >= 0; t--) {
      const nxt = t === n - 1 ? nv : b.val[t + 1], nt = b.done[t] ? 0 : 1;
      gae = b.rew[t] + gamma * nxt * nt - b.val[t] + gamma * lam * nt * gae;
      adv[t] = gae; ret[t] = gae + b.val[t];
    }
    this.hp.freeze = this.freezeLeft > 0; if (this.freezeLeft > 0) this.freezeLeft--;      // after imitation: let the critic catch up first
    this.stats.diag = this.agent.update({ obs: b.obs, act: b.act, logp: b.logp, adv, ret }, this.hp);
    if (this.hp.anchor && !this.hp.freeze) {                    // keep pulling the policy towards what the human did, so RL refines it instead of wandering off
      const D = this.demo.dataset(this.kind === 'glb' ? 'real' : 'game');
      if (D.n >= 300) for (let q = 0; q < this.hp.anchorSteps; q++) bcStep(this.agent, D, 64, this.hp.lr * 2);
    }
    this.stats.updates++;
    this.clearBuf();
    if (!this.hp.freeze && this.stats.updates % this.hp.evalEvery === 0) this.checkpoint();
  }

  // Noise-free test drive from the start line, in the current conditions.
  evalPolicy() {
    const c = this.evalCar, tr = this.tr; c.reset(tr, 0);
    let n = 0, res = null;
    while (n < 20000) {
      const o = Float64Array.from(c.sense(tr)); res = c.step(tr, this.agent.act(o, true).a, this.hp); n++;
      if (res.done) break;
    }
    const frac = clamp(c.dist / tr.lapLen, 0, 1), lap = !!res && res.kind === 'lap', t = n * DT;
    return { frac, lap, t, score: lap ? 1 + (600 - t) / 600 : frac };
  }

  // Keep the best brain seen so far per condition (the "champion"); if the live brain collapses, go back to it.
  checkpoint() {
    const e = this.evalPolicy(), key = this.env.key(), ch = this.champ[key];
    this.lastEval = Object.assign({ key }, e);
    if (!ch || e.score > ch.score) {
      this.champ[key] = Object.assign({}, e, { w: this.agent.toJSON() }); this.bad = 0; this.stale = 0;
      this.scaleNoise(0.9);                                           // it got better: explore a little less
      this.events.push({ type: 'champ', frac: e.frac, lap: e.lap, t: e.t });
    } else if (e.score < ch.score * 0.5) {
      if (++this.bad >= 4 && this.hp.rollback) { this.agent.fromJSON(ch.w); this.bad = 0; this.events.push({ type: 'rollback', frac: ch.frac }); }
    } else this.bad = 0;
    if (this.champ[key] && e.score <= this.champ[key].score && ++this.stale >= 10) { this.stale = 0; this.scaleNoise(1.12); }   // stuck: explore more
  }

  scaleNoise(f) {
    if (!this.hp.adaptNoise) return;
    const ls = this.agent.logStd;
    for (let k = 0; k < ls.length; k++) ls[k] = clamp(ls[k] + Math.log(f), Math.log(this.hp.stdFloor), Math.log(this.hp.stdCeil));
  }

  restoreChampion() {
    const ch = this.champ[this.env.key()] || Object.values(this.champ).sort((a, b) => b.score - a.score)[0];
    if (!ch) return false;
    this.agent.fromJSON(ch.w); this.clearBuf(); this.respawn(); return true;
  }

  avgRecent(k = 10) {
    const h = this.stats.hist.slice(-k);
    return h.length ? h.reduce((a, x) => a + x.d, 0) / h.length : 0;
  }

  toJSON() {
    const st = Object.assign({}, this.stats); delete st.log; delete st.diag;
    const hp = Object.assign({}, this.hp); delete hp.freeze;
    return { v: 2, agent: this.agent.toJSON(), hp, kind: this.kind, stats: st, env: { dayMode: this.env.dayMode, weatherMode: this.env.weatherMode }, cur: this.cur, champ: this.champ };
  }
  fromJSON(j) {
    if (j.v !== 2) throw new Error('This save is from an older version (different sensors). Start a new brain.');
    this.agent.fromJSON(j.agent); Object.assign(this.hp, j.hp);
    this.setTrack(j.kind || this.kind);
    if (j.stats) Object.assign(this.stats, j.stats);
    if (j.env) { this.env.dayMode = j.env.dayMode; this.env.weatherMode = j.env.weatherMode; }
    if (j.cur) Object.assign(this.cur, j.cur);
    this.champ = j.champ || {};
  }
}
