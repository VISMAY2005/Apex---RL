const $ = id => document.getElementById(id);
const T = new Trainer(new URLSearchParams(location.search).get('track') === 'nord' ? 'nord' : new URLSearchParams(location.search).get('track') === 'practice' ? 'practice' : 'glb');
const cv = $('game'), g = cv.getContext('2d'), mini = $('mini'), mg = mini.getContext('2d');
let VW = 0, VH = 0, DPR = 1;
let tiles, ov, tv = -1, lamps = [], ghostClock = null, driver = DRIVERS[5];
let speed = 1, running = true, mapMode = false, acc = 0, zoom = 2.3, camX = 0, camY = 0;
const crashMarks = []; let fx = null;
const light = new Lighting(), rain = new Rain(), spray = new Spray(), v3 = new View3D(), gl3 = new ViewGLB();
$('track').value = T.kind;
let view = '3d';

function resize() { DPR = Math.min(window.devicePixelRatio || 1, 1.5); VW = innerWidth; VH = innerHeight; cv.width = VW * DPR; cv.height = VH * DPR; light.resize(VW, VH, DPR); v3.setRes(parseInt($('res3d').value), VW / VH); gl3.setRes(parseInt($('res3d').value), VW / VH); if (v3.tr) v3.setTrack(v3.tr, lamps); }
addEventListener('resize', resize); resize();
loadCarSprite();
loadArt3D().then(() => { tv = -1; });                 // optional extra art (assets/car_back.png, trees, sky, textures ...)

/* ---------- controls ---------- */
const SPEEDS = [[0.5, '0.5×'], [1, '1×'], [2, '2×'], [4, '4×'], [8, '8×'], [16, '16×'], [32, '32×'], ['max', 'Max']];
for (const [v, label] of SPEEDS) {
  const b = document.createElement('button'); b.textContent = label; b.dataset.v = v;
  b.onclick = () => setSpeed(v); $('speeds').appendChild(b);
}
function setSpeed(v) { speed = v; acc = 0; for (const b of $('speeds').children) b.classList.toggle('on', b.dataset.v === String(v)); }
setSpeed(1);
function setView(v) { view = v; $('viewbtn').textContent = v === '3d' ? 'View: 3D chase (V)' : 'View: top-down (V)'; $('viewbtn').classList.toggle('on', v === '3d'); }
$('viewbtn').onclick = () => setView(view === '3d' ? '2d' : '3d'); setView('3d');
$('res3d').onchange = () => { gl3.setRes(parseInt($('res3d').value), VW / VH); v3.setRes(parseInt($('res3d').value), VW / VH); if (v3.tr) v3.setTrack(v3.tr, lamps); };
$('camdist').oninput = () => { v3.camDist = gl3.camDist = parseFloat($('camdist').value); $('camdistv').textContent = v3.camDist; };
$('camh').oninput = () => { v3.camH = gl3.camH = parseFloat($('camh').value); $('camhv').textContent = v3.camH; };
function setPause(p) { running = !p; $('pause').textContent = p ? 'Resume' : 'Pause'; $('pause').classList.toggle('on', p); }
$('pause').onclick = () => setPause(running);
function setMap(m) { mapMode = m; $('mapbtn').classList.toggle('on', m); $('mapbtn').textContent = m ? 'Back to car (M)' : 'Full map (M)'; }
$('mapbtn').onclick = () => setMap(!mapMode);
function setDrawer(o) { $('drawer').classList.toggle('open', o); $('drawer').setAttribute('aria-hidden', String(!o)); }
$('menubtn').onclick = () => setDrawer(!$('drawer').classList.contains('open'));
$('closebtn').onclick = () => setDrawer(false);
function setManual(on) {
  if (T.busy || on === T.manual) return;
  if (on) { prevSpeed = speed; setSpeed(1); setPause(false); setMap(false); }
  T.setManual(on);
  $('drivebtn').classList.toggle('on', on); $('drivebtn').textContent = on ? 'Stop driving (D)' : 'Drive yourself (D)';
  if (!on) setSpeed(prevSpeed);
  banner(on ? 'You are driving: arrows to steer and use the pedals, Space = handbrake' : 'The AI is driving again', 'info');
}
let prevSpeed = 1;
$('drivebtn').onclick = () => setManual(!T.manual);
addEventListener('keydown', e => {
  if (/INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
  if (T.manual && HumanInput.isDriveKey(e.code)) { e.preventDefault(); T.keys.press(e.code, true); return; }      // arrows + space drive the car
  if (e.key === 'm' || e.key === 'M') setMap(!mapMode);
  else if (e.key === 'v' || e.key === 'V') setView(view === '3d' ? '2d' : '3d');
  else if (e.key === 'd' || e.key === 'D') setManual(!T.manual);
  else if (e.key === 'p' || e.key === 'P') setPause(running);
  else if ((e.key === 'r' || e.key === 'R') && T.manual) { T.flushDemo(); T.humanResume = 0; T.car.reset(T.tr, 0, 0); T.keys.clear(); banner('Back at the start line', 'info'); }
  else if (e.key === ' ') { e.preventDefault(); setPause(running); }
  else if (e.key === 'Tab') { e.preventDefault(); setDrawer(!$('drawer').classList.contains('open')); }
});
addEventListener('keyup', e => { if (HumanInput.isDriveKey(e.code)) { T.keys.press(e.code, false); if (T.manual) e.preventDefault(); } });
addEventListener('blur', () => T.keys.clear());                                                                  // never leave a key "stuck" when the window loses focus
document.addEventListener('click', e => { if (e.target.tagName === 'BUTTON') e.target.blur(); });               // so Space does not re-press the last button you clicked
document.addEventListener('change', e => { if (/INPUT|SELECT/.test(e.target.tagName)) e.target.blur(); });

const sliders = [
  ['lr', 'Learning rate', 5e-5, 1e-3, 5e-5, v => v.toExponential(1)],
  ['entropy', 'Exploration bonus', 0, 0.02, 0.0005, v => v.toFixed(4)],
  ['wProg', 'Reward: progress', 0.01, 0.2, 0.005, v => v.toFixed(3)],
  ['wSpeed', 'Reward: speed', 0, 0.08, 0.002, v => v.toFixed(3)],
  ['wCenter', 'Penalty: off-centre', 0, 0.3, 0.005, v => v.toFixed(3)],
  ['wSafe', 'Penalty: too fast for the road ahead', 0, 1.5, 0.05, v => v.toFixed(2)],
  ['crash', 'Penalty: crash', 1, 15, 0.5, v => v.toFixed(1)],
];
for (const [k, label, min, max, step, fmt] of sliders) {
  $('sliders').insertAdjacentHTML('beforeend', `<label class="row"><span>${label}</span><output id="o_${k}"></output><input type="range" id="s_${k}" min="${min}" max="${max}" step="${step}"></label>`);
  $('s_' + k).oninput = () => { T.hp[k] = parseFloat($('s_' + k).value); $('o_' + k).textContent = fmt(T.hp[k]); };
}
function syncSliders() {
  for (const [k, , , , , fmt] of sliders) { $('s_' + k).value = T.hp[k]; $('o_' + k).textContent = fmt(T.hp[k]); }
  $('anchor').checked = T.hp.anchor; $('smart').checked = T.hp.smart; $('adapt').checked = T.hp.adaptNoise; $('rollback').checked = T.hp.rollback; $('daymode').value = T.env.dayMode; $('weather').value = T.env.weatherMode; $('curr').checked = T.cur.on;
}
syncSliders();
$('smart').onchange = () => T.hp.smart = $('smart').checked;
$('adapt').onchange = () => T.hp.adaptNoise = $('adapt').checked;
$('rollback').onchange = () => T.hp.rollback = $('rollback').checked;
$('champbtn').onclick = () => banner(T.restoreChampion() ? 'Champion brain restored' : 'No champion yet', 'info');
$('zoom').oninput = () => { zoom = parseFloat($('zoom').value); $('zoomv').textContent = zoom.toFixed(1) + '×'; }; $('zoomv').textContent = '2.3×';
$('mode').onchange = () => { T.evalMode = $('mode').value === 'drive'; T.clearBuf(); T.respawn(); banner(T.evalMode ? 'Drive mode: no noise, no learning' : 'Training mode', 'info'); };
$('track').onchange = () => { T.setTrack($('track').value); crashMarks.length = 0; banner('Loaded ' + T.tr.name, 'info'); };
$('reset').onclick = () => { if (confirm('Throw away the trained brain and start from scratch?')) { T.agent = new PPOAgent(NIN, 2); T.setTrack(T.kind); crashMarks.length = 0; banner('Brain reset', 'info'); } };
$('save').onclick = async () => { const r = await fetch('/api/save', { method: 'POST', body: JSON.stringify(T.toJSON()) }); banner(r.ok ? 'Saved to saves/brain.json' : 'Save failed', 'info'); };
$('load').onclick = async () => {
  const r = await fetch('/api/load'); if (!r.ok) return banner('No saved brain yet', 'info');
  try { T.fromJSON(await r.json()); $('track').value = T.kind; syncSliders(); crashMarks.length = 0; banner('Brain loaded', 'info'); }
  catch (e) { banner(e.message, 'crash'); }
};
$('csv').onclick = () => {
  const rows = ['attempt,meters,started_at_line,conditions,result,seconds', ...T.stats.log.map(r => r.join(','))];
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([rows.join('\n')], { type: 'text/csv' })); a.download = 'apexrl_attempts.csv'; a.click();
};

/* drive it yourself: recording, saving, learning from your laps */
$('rec').onchange = () => { T.recordDemo = $('rec').checked; if (!T.recordDemo) T.demo.discardCurrent(); };
$('atline').onchange = () => T.restartAtLine = $('atline').checked;
$('anchor').onchange = () => T.hp.anchor = $('anchor').checked;
$('eps').oninput = () => $('epv').textContent = $('eps').value;
$('undorun').onclick = () => { const r = T.demo.undoLast(); banner(r ? `Discarded your last run (${r.m} m)` : 'No recorded run to discard', 'info'); };
$('cleardemo').onclick = () => { if (confirm('Throw away everything recorded in this session? (Laps already saved to saves/demos.json stay in the file.)')) { T.demo.clear(); banner('Recording cleared', 'info'); } };
$('savedemo').onclick = async () => {
  T.flushDemo(); const runs = T.demo.unsaved(); if (!runs.length) return banner('Nothing new to save', 'info');
  try {
    const r = await fetch('/api/demos/save', { method: 'POST', body: JSON.stringify({ runs }) });
    if (!r.ok) throw new Error((await r.json()).error || 'server error');
    const j = await r.json(); T.demo.savedUpTo = T.demo.runs.length; banner(`Saved ${j.added} new runs (${j.total} in saves/demos.json)`, 'info');
  } catch (e) { banner('Save failed: ' + e.message, 'crash'); }
};
$('loaddemo').onclick = async () => {
  if (T.demo.runs.length > T.demo.savedUpTo && !confirm('You have recorded laps that are not saved yet. Loading replaces them. Continue?')) return;
  try {
    const r = await fetch('/api/demos/load'); if (!r.ok) return banner('No saved laps yet', 'info');
    T.demo.replaceWith((await r.json()).runs); banner(`Loaded ${T.demo.runs.length} saved runs`, 'info');
  } catch (e) { banner('Load failed: ' + e.message, 'crash'); }
};
$('learndemo').onclick = async () => {
  if (T.busy) return; if (T.manual) setManual(false);   // leaving manual mode keeps the run in progress
  T.busy = true; $('learndemo').disabled = true;
  try {
    const r = await learnFromDemos(T, parseInt($('eps').value), m => banner(m, 'info')), e = r.test;
    banner(`Learned from ${Math.round(r.frames * DT)} s of your driving. Noise-free test drive: ${Math.round(e.frac * 100)}% of the lap${e.lap ? ' (full lap!)' : ''}. Normal learning continues from here.`, 'lap');
  } catch (e) { banner(e.message, 'crash'); }
  T.busy = false; $('learndemo').disabled = false;
};
let lastDemoInfo = 0;
function demoInfo() {
  const now = performance.now(); if (now - lastDemoInfo < 500 || !$('drawer').classList.contains('open')) return; lastDemoInfo = now;
  const ph = T.kind === 'glb' ? 'real' : 'game', f = T.demo.frames(ph), runs = T.demo.runs.filter(r => r.phys === ph).length, other = T.demo.runs.length - runs, un = T.demo.runs.length - T.demo.savedUpTo;
  $('demoinfo').textContent = (f ? `Recorded for this track type: ${runs} runs, ${(T.demo.meters(ph) / 1000).toFixed(2)} km, ${Math.round(f * DT)} s of driving, ${T.demo.laps(ph)} full laps from the line.` : 'No laps recorded yet for this track type.')
    + (other ? ` (${other} more recorded on the other physics, not used here.)` : '') + (un > 0 ? ` ${un} runs not saved yet.` : '') + (T.human.best !== null ? ` Your best lap: ${fmtT(T.human.best).slice(0, 6)}.` : '');
}
function driveBar() {
  const b = $('drivebar'); b.hidden = !T.manual; if (!T.manual) return;
  const ph = T.kind === 'glb' ? 'real' : 'game', sec = Math.round((T.demo.frames(ph) + T.demo.ep.obs.length) * DT);
  const html = (T.recordDemo ? '<i class="rec"></i>REC' : 'NOT RECORDING') + ` · ${sec} s recorded · ${T.demo.runs.length} runs · ${T.demo.laps(ph)} full laps`;
  if (html !== b._h) { b.innerHTML = html; b._h = html; }
}

/* conditions */
const manualEnv = () => { T.cur.on = false; $('curr').checked = false; T.env.dayMode = $('daymode').value; T.env.weatherMode = $('weather').value; };
$('daymode').onchange = manualEnv; $('weather').onchange = manualEnv;
$('curr').onchange = () => {
  T.cur.on = $('curr').checked;
  if (T.cur.on) { T.cur.stage = 0; T.cur.from = T.stats.attempts; [T.env.dayMode, T.env.weatherMode] = STAGES[0]; syncSliders(); banner('Curriculum on: starts easy (day, sunny)', 'info'); }
};

/* drivers + ghost */
for (const d of DRIVERS) $('driver').insertAdjacentHTML('beforeend', `<option value="${d.id}">${d.who} · ${fmtT(d.t)}</option>`);
$('driver').value = driver.id;
function setDriver() {
  driver = DRIVERS.find(d => d.id === $('driver').value);
  $('driverinfo').textContent = `${driver.car}, ${driver.year}. ${driver.note}. Lap ${fmtT(driver.t)}.`;
  ghostClock = buildGhostClock(T.tr, driver.t);
}
$('driver').onchange = setDriver;
$('study').onclick = async () => {
  if (T.busy) return;
  T.busy = true; $('study').disabled = true;
  const ideal = new Expert(T.tr, 1).lapTime(), pace = clamp(ideal / driver.t, 0.45, 1);
  try {
    await imitate(T, pace, m => banner(m, 'info'));
    banner(`Studied ${driver.who}: teacher paced at ${Math.round(pace * 100)}% of its limit. Now learning on its own.`, 'lap');
  } catch (e) { banner('Study failed: ' + e.message, 'crash'); }
  T.busy = false; $('study').disabled = false;
};

let bt; function banner(msg, cls) { const b = $('banner'); b.textContent = msg; b.className = 'glass on ' + cls; clearTimeout(bt); bt = setTimeout(() => b.classList.remove('on'), cls === 'info' ? 1800 : 2600); }

/* ---------- LLM coach ---------- */
async function askCoach() {
  $('coachbtn').disabled = true; $('coachtxt').textContent = 'Asking the coach...';
  const s = T.stats, r10 = s.hist.slice(-10).map(h => Math.round(h.d));
  const payload = {
    stats: { lapKm: +(T.tr.lapLen / PXM / 1000).toFixed(2), conditions: T.env.key(), attempts: s.attempts, updates: s.updates, avgRecentMeters: Math.round(T.avgRecent(10)), bestMeters: Math.round(s.bestM), furthestKm: +(s.maxReach / PXM / 1000).toFixed(2), lapsCompleted: s.laps, bestLapSeconds: s.bestLap, recentMeters: r10, actionStd: s.diag ? s.diag.std.map(v => +v.toFixed(2)) : null },
    hp: { lr: T.hp.lr, entropy: T.hp.entropy, wProg: T.hp.wProg, wSpeed: T.hp.wSpeed, wCenter: T.hp.wCenter, wSafe: T.hp.wSafe, crash: T.hp.crash },
  };
  try {
    const r = await (await fetch('/api/coach', { method: 'POST', body: JSON.stringify(payload) })).json();
    if (r.error) throw new Error(r.error);
    const lim = { lr: [1e-4, 2e-3], entropy: [0, 0.02], wProg: [0.01, 0.2], wSpeed: [0, 0.08], wCenter: [0, 0.3], wSafe: [0, 1.5], crash: [1, 15] }, applied = [];
    for (const [k, v] of Object.entries(r.changes || {})) if (lim[k] && typeof v === 'number') { T.hp[k] = clamp(v, lim[k][0], lim[k][1]); applied.push(`${k}=${T.hp[k].toPrecision(3)}`); }
    syncSliders();
    $('coachtxt').innerHTML = `<b>${r.provider}</b>: ${r.explanation || ''}<br><small>${applied.length ? 'Applied: ' + applied.join(', ') : 'No changes suggested.'}</small>`;
  } catch (e) { $('coachtxt').textContent = 'Coach error: ' + e.message; }
  $('coachbtn').disabled = false;
}
$('coachbtn').onclick = askCoach;
let lastCoach = 0, lastChamp = 0;

/* ---------- HUD ---------- */
function drawChart() {
  const c = $('chart'), x = c.getContext('2d'), w = c.width, h = c.height, H = T.stats.hist;
  x.clearRect(0, 0, w, h);
  const top = Math.max(300, ...H.map(p => p.d)) * 1.05;
  x.strokeStyle = '#2f343e'; x.lineWidth = 1;
  for (let i = 0; i <= 3; i++) { const y = 4 + (h - 8) * i / 3; x.beginPath(); x.moveTo(0, y); x.lineTo(w, y); x.stroke(); }
  if (!H.length) return;
  const px = i => 4 + i / Math.max(H.length - 1, 40) * (w - 8), py = d => h - 4 - (h - 8) * d / top;
  x.fillStyle = 'rgba(255,255,255,.5)'; H.forEach((p, i) => { x.beginPath(); x.arc(px(i), py(p.d), 1.8, 0, 7); x.fill(); });
  x.strokeStyle = '#ffb81c'; x.lineWidth = 2; x.beginPath();
  H.forEach((p, i) => { const a = H.slice(Math.max(0, i - 9), i + 1); const m = a.reduce((s, q) => s + q.d, 0) / a.length; i ? x.lineTo(px(i), py(m)) : x.moveTo(px(i), py(m)); }); x.stroke();
  $('h_max').textContent = `  (top = ${Math.round(top)} m)`;
}
function condText() {
  const parts = [ENV.night > 0.5 ? 'Night' : ENV.night > 0.15 ? 'Dusk' : 'Day'];
  parts.push(ENV.rain > 0.15 ? `Rain ${Math.round(ENV.rain * 100)}%` : ENV.wet > 0.15 ? 'Damp track' : 'Sunny');
  if (T.env.dayMode === 'auto') parts.push(T.env.clock());
  if (T.cur.on) parts.push(`stage ${T.cur.stage + 1}/4`);
  return parts.join(' · ');
}
function hud() {
  const s = T.stats, c = T.car;
  $('trackname').textContent = T.tr.name; $('h_cond').textContent = condText();
  const le = T.lastEval, ch = T.champ[T.env.key()];
  $('h_champ').textContent = le ? `Test drive (no noise): ${Math.round(le.frac * 100)}%${le.lap ? ' LAP ' + fmtT(le.t).slice(0, 6) : ''}  ·  champion ${ch ? Math.round(ch.frac * 100) + '%' + (ch.lap ? ' LAP ' + fmtT(ch.t).slice(0, 6) : '') : '--'}  ·  noise ${T.agent.logStd.map(v => Math.exp(v).toFixed(2)).join('/')}` : 'Test drive (no noise): not yet run';
  $('h_att').textContent = s.attempts + 1;
  $('h_run').textContent = Math.round(Math.max(0, c.dist) / PXM) + ' m';
  $('h_best').textContent = Math.round(s.bestM) + ' m';
  $('h_avg').textContent = Math.round(T.avgRecent(10)) + ' m';
  $('h_far').textContent = Math.round(Math.min(1, s.maxReach / T.tr.lapLen) * 100) + '%';
  $('h_laps').textContent = s.laps + ' / ' + (s.bestLap === null ? '--' : fmtT(s.bestLap).slice(0, 6));
  drawChart(); driveBar();
}
let lastCond = 0;
function condTable() {
  const now = performance.now(); if (now - lastCond < 1000 || !$('drawer').classList.contains('open')) return; lastCond = now;
  const rows = Object.entries(T.stats.byCond).sort();
  $('cond').innerHTML = '<tr><th>Conditions</th><th>Attempts</th><th>Best</th><th>Avg</th></tr>' + (rows.length ? rows.map(([k, v]) => `<tr><td>${k}</td><td>${v.n}</td><td>${Math.round(v.best)} m</td><td>${Math.round(v.avg)} m</td></tr>`).join('') : '<tr><td colspan="4">No attempts yet</td></tr>');
}
function ghostGap() {
  if ($('ghost').value !== 'ref' || !ghostClock) { $('d_gap').textContent = ''; return; }
  const c = T.car, t = ghostClock, sp = T.tr.spacing, i0 = Math.floor(c.startPx / sp), fi = clamp((c.startPx + c.dist) / sp, 0, T.tr.M - 1e-6), k = Math.floor(fi);
  const tg = t[k] + (t[k + 1] - t[k]) * (fi - k) - t[i0], gap = c.steps * DT - tg;
  $('d_gap').style.color = gap > 0 ? '#ff8a8f' : '#4be0a0';
  $('d_gap').textContent = `${gap > 0 ? '+' : '-'}${Math.abs(gap).toFixed(1)} s ${gap > 0 ? 'behind' : 'ahead of'} ${driver.who.split(' ')[0]}`;
}
function meters() {
  const c = T.car;
  $('d_kmh').textContent = Math.round(c.v / PXM * 3.6);
  const bar = (id, val, col) => { const st = $(id).style; st.left = val >= 0 ? '50%' : (50 + val * 50) + '%'; st.width = Math.abs(val) * 50 + '%'; if (col) st.background = col; };
  bar('d_steer', c.cmdS); bar('d_thr', c.cmdT, c.cmdT >= 0 ? '#4be0a0' : '#e0252f');
  const sl = clamp(c.slip / 0.5, -1, 1); bar('d_slip', sl, Math.abs(sl) > 0.5 ? '#e0252f' : '#ffb81c');
  $('d_hb').textContent = c.hb ? 'ON' : 'OFF'; $('d_hb').classList.toggle('on', !!c.hb);
  ghostGap();
}

/* ---------- drawing ---------- */
const lerp = (a, b, t) => a + (b - a) * t;
function angLerp(a, b, t) { let d = b - a; d = Math.atan2(Math.sin(d), Math.cos(d)); return a + d * t; }
const lightsMix = () => Math.max(clamp((ENV.night - 0.3) / 0.4, 0, 1), clamp((ENV.rain - 0.4) / 0.4, 0, 1));

function ghostPose(c, alpha) {
  const mode = $('ghost').value, tr = T.tr; let gx, gy, gh, label;
  if (mode === 'ref' && ghostClock) {
    const sec = ghostClock[Math.floor(c.startPx / tr.spacing)] + (c.steps + alpha) * DT;
    if (sec >= ghostClock[tr.M]) return null;
    const f = ghostIndexAt(ghostClock, sec), i = Math.floor(f) % tr.M, j = (i + 1) % tr.M, u = f - Math.floor(f);
    gx = lerp(tr.xs[i], tr.xs[j], u); gy = lerp(tr.ys[i], tr.ys[j], u); gh = Math.atan2(lerp(tr.ty[i], tr.ty[j], u), lerp(tr.tx[i], tr.tx[j], u)); label = driver.who.split(' ')[0] + ' ' + fmtT(driver.t).slice(0, 6);
  } else if (mode === 'best' && T.bestRec && c.startPx < 1) {
    const n = T.bestRec.length / 3, k = Math.min(n - 1, c.steps);
    gx = T.bestRec[3 * k]; gy = T.bestRec[3 * k + 1]; gh = T.bestRec[3 * k + 2]; label = 'My best ' + fmtT(T.stats.bestLap).slice(0, 6);
  } else return null;
  return { x: gx, y: gy, h: gh, label };
}

function drawGhost(c, alpha, mix) {
  const p = ghostPose(c, alpha); if (!p) return;
  const gx = p.x, gy = p.y, label = p.label;
  drawCar(g, p.x, p.y, p.h, 0.5, mix);
  g.fillStyle = 'rgba(255,255,255,.9)'; g.font = `600 ${13 / zoom * 1.6}px system-ui, sans-serif`; g.textAlign = 'center'; g.fillText(label, gx, gy - 24); g.textAlign = 'left';
}

function drawWorld(alpha, dt) {
  const tr = T.tr, c = T.car, mix = lightsMix();
  const cx = lerp(c.px, c.x, alpha), cy = lerp(c.py, c.y, alpha), ch = angLerp(c.ph, c.h, alpha);
  const tx = cx + Math.cos(ch) * 40, ty = cy + Math.sin(ch) * 40;
  if (Math.hypot(tx - camX, ty - camY) > 500) { camX = tx; camY = ty; }          // after a respawn far away, jump instead of flying across the map
  camX += (tx - camX) * 0.14; camY += (ty - camY) * 0.14;
  g.setTransform(DPR, 0, 0, DPR, 0, 0); g.fillStyle = '#1e4a22'; g.fillRect(0, 0, VW, VH);
  g.setTransform(DPR * zoom, 0, 0, DPR * zoom, DPR * (VW / 2 - camX * zoom), DPR * (VH / 2 - camY * zoom));
  const vx0 = camX - VW / 2 / zoom, vx1 = camX + VW / 2 / zoom, vy0 = camY - VH / 2 / zoom, vy1 = camY + VH / 2 / zoom;
  let built = 0;
  for (let ty2 = Math.floor(vy0 / TS); ty2 <= Math.floor(vy1 / TS); ty2++)
    for (let tx2 = Math.floor(vx0 / TS); tx2 <= Math.floor(vx1 / TS); tx2++) {
      if (tx2 < 0 || ty2 < 0 || tx2 * TS > tr.WW || ty2 * TS > tr.WH) continue;
      const had = tiles.map.has(ty2 * 4096 + tx2), t = tiles.get(tx2, ty2, built < 3);
      if (!had && t) built++;
      if (t) g.drawImage(t, tx2 * TS - 0.3, ty2 * TS - 0.3, TS + 0.6, TS + 0.6);
    }
  drawLampPosts(g, lamps, vx0 - 20, vx1 + 20, vy0 - 20, vy1 + 20);
  for (let i = 0; i < crashMarks.length; i++) {                      // where it has crashed before
    const m = crashMarks[i], a = 0.15 + 0.7 * (i / crashMarks.length);
    g.strokeStyle = `rgba(255,70,70,${a})`; g.lineWidth = 2.5;
    g.beginPath(); g.moveTo(m.x - 7, m.y - 7); g.lineTo(m.x + 7, m.y + 7); g.moveTo(m.x + 7, m.y - 7); g.lineTo(m.x - 7, m.y + 7); g.stroke();
  }
  drawGhost(c, alpha, mix);
  drawCar(g, cx, cy, ch, 1, mix);
  spray.draw(g);
  light.draw(g, { lamps, car: { x: cx, y: cy, h: ch }, zoom, camX, camY, VW, VH, DPR });          // overcast tint, night darkness, lamp + headlight glow
  g.setTransform(DPR * zoom, 0, 0, DPR * zoom, DPR * (VW / 2 - camX * zoom), DPR * (VH / 2 - camY * zoom));
  if ($('sens').value === 'on') {
    c.sense(tr);
    for (let i = 0; i < RAYS.length; i++) {
      const r = c.reading[i], col = `hsla(${Math.round(r * 120)},95%,58%,.9)`;
      g.strokeStyle = col; g.lineWidth = 1.4; g.beginPath(); g.moveTo(c.ox, c.oy); g.lineTo(c.hx[i], c.hy[i]); g.stroke();
      g.fillStyle = col; g.beginPath(); g.arc(c.hx[i], c.hy[i], 2.6, 0, 7); g.fill();
    }
  }
  if (fx) {
    const age = (performance.now() - fx.t) / 700;
    if (age < 1) { g.strokeStyle = `rgba(255,80,60,${1 - age})`; g.lineWidth = 4; g.beginPath(); g.arc(fx.x, fx.y, 14 + age * 70, 0, 7); g.stroke(); } else fx = null;
  }
  rain.draw(g, VW, VH, DPR, running ? dt : 0);
}

function drawGL(alpha, dt) {                                      // the real 3D model (three.js)
  g.setTransform(DPR, 0, 0, DPR, 0, 0); g.imageSmoothingEnabled = false; g.fillStyle = '#0b0e14'; g.fillRect(0, 0, VW, VH);
  if (gl3.state === 'idle') gl3.ensure();
  if (gl3.state !== 'ready') {
    g.fillStyle = '#eceef2'; g.font = '600 18px system-ui, sans-serif'; g.textAlign = 'center';
    g.fillText(gl3.state === 'failed' ? '3D model failed: ' + gl3.msg : gl3.msg + (gl3.pct ? '  ' + Math.round(gl3.pct * 100) + '%' : ''), VW / 2, VH / 2);
    if (gl3.state === 'failed') { g.font = '14px system-ui, sans-serif'; g.fillText('Press V for the top-down view, or fix the problem and reload.', VW / 2, VH / 2 + 28); }
    g.textAlign = 'left'; return;
  }
  const c = T.car, show = $('sens').value === 'on';
  const car = { x: lerp(c.px, c.x, alpha), y: lerp(c.py, c.y, alpha), h: angLerp(c.ph, c.h, alpha), v: c.v, vang: c.vang };
  if (show) c.sense(T.tr);
  const cv = gl3.render({ car, idx: c.idx, dt, mix: lightsMix(), showRays: show, rays: c });
  g.drawImage(cv, 0, 0, VW, VH);
  rain.draw(g, VW, VH, DPR, running ? dt : 0);
}

function draw3d(alpha, dt) {
  if (T.tr.glb) return drawGL(alpha, dt);
  const c = T.car, show = $('sens').value === 'on';
  const car = { x: lerp(c.px, c.x, alpha), y: lerp(c.py, c.y, alpha), h: angLerp(c.ph, c.h, alpha), v: c.v, vang: c.vang, cmdS: c.cmdS, cmdT: c.cmdT };
  const gp = ghostPose(c, alpha); if (show) c.sense(T.tr);
  const o = v3.render({ car, idx: c.idx, dt, ghosts: gp ? [gp] : [], mix: lightsMix(), spray: spray.p, showRays: show, rays: c });
  g.setTransform(DPR, 0, 0, DPR, 0, 0); g.imageSmoothingEnabled = false; g.fillStyle = '#000'; g.fillRect(0, 0, VW, VH);
  g.drawImage(v3.cv, o.sx, o.sy, VW, VH);
}

function drawMarkers(gc, ox, oy, sc, big) {
  const tr = T.tr, c = T.car;
  for (let i = 0; i < crashMarks.length; i++) {
    const m = crashMarks[i]; gc.fillStyle = `rgba(255,70,70,${0.25 + 0.6 * i / crashMarks.length})`;
    gc.beginPath(); gc.arc(ox + m.x * sc, oy + m.y * sc, big ? 3.5 : 2, 0, 7); gc.fill();
  }
  const fi = Math.floor(T.stats.maxReach / tr.spacing) % tr.M;
  gc.fillStyle = '#4be0a0'; gc.beginPath(); gc.arc(ox + tr.xs[fi] * sc, oy + tr.ys[fi] * sc, big ? 7 : 4, 0, 7); gc.fill();
  if (big) {                                                          // km markers
    gc.fillStyle = '#eceef2'; gc.font = '600 12px system-ui, sans-serif';
    for (let km = 5; km * 1000 * PXM < tr.lapLen; km += 5) { const i = Math.floor(km * 1000 * PXM / tr.spacing); gc.fillText(km + ' km', ox + tr.xs[i] * sc + 8, oy + tr.ys[i] * sc - 8); gc.fillRect(ox + tr.xs[i] * sc - 2, oy + tr.ys[i] * sc - 2, 4, 4); }
  }
  const pulse = 1 + 0.25 * Math.sin(performance.now() / 180), r = (big ? 9 : 5) * pulse;
  gc.strokeStyle = '#ffb81c'; gc.lineWidth = 2.5; gc.beginPath(); gc.arc(ox + c.x * sc, oy + c.y * sc, r, 0, 7); gc.stroke();
  gc.fillStyle = '#fff'; gc.beginPath(); gc.arc(ox + c.x * sc, oy + c.y * sc, big ? 3.5 : 2.2, 0, 7); gc.fill();
}

function drawMap() {
  const k = Math.min((VW - 40) / ov.W, (VH - 40) / ov.H), w = ov.W * k, h = ov.H * k, ox = (VW - w) / 2, oy = (VH - h) / 2;
  g.setTransform(DPR, 0, 0, DPR, 0, 0); g.fillStyle = '#0c1a0f'; g.fillRect(0, 0, VW, VH);
  g.drawImage(ov.cache, ox, oy, w, h);
  drawMarkers(g, ox, oy, ov.sc * k, true);
  g.fillStyle = '#eceef2'; g.font = '600 15px system-ui, sans-serif';
  g.fillText(`${T.tr.name}  ·  green = furthest reached (${Math.round(T.stats.maxReach / T.tr.lapLen * 100)}%)  ·  red dots = recent crashes`, VW / 2 - 330, VH - 16);
}

function drawMini() {
  const k = Math.min(mini.width / ov.W, mini.height / ov.H), w = ov.W * k, h = ov.H * k, ox = (mini.width - w) / 2, oy = (mini.height - h) / 2;
  mg.clearRect(0, 0, mini.width, mini.height);
  mg.drawImage(ov.cache, ox, oy, w, h);
  drawMarkers(mg, ox, oy, ov.sc * k, false);
}

/* ---------- main loop ---------- */
let last = performance.now(), frameN = 0;
function frame(now) {
  const dt = Math.min(0.1, (now - last) / 1000); last = now;
  if (T.trackVersion !== tv) { tv = T.trackVersion; tiles = new TileCache(T.tr); ov = buildOverview(T.tr); lamps = buildLamps(T.tr); camX = T.car.x; camY = T.car.y; setDriver(); CAR_IMG.length = T.tr.glb ? 17 : 46; if (T.tr.glb) gl3.setTrack(T.tr); else v3.setTrack(T.tr, lamps); }
  let alpha = 1;
  if (T.manual && speed !== 1) setSpeed(1);                                       // you cannot drive in fast-forward
  if (running && !T.busy) {
    const t0 = performance.now();
    if (speed === 'max') { const budget = view === '3d' ? (frameN % 3 === 0 ? 8 : 30) : 12; while (performance.now() - t0 < budget) for (let i = 0; i < 25; i++) T.tick(); }   // 3D is drawn on every 3rd frame at high speed so training keeps its pace
    else {
      acc += dt * 30 * speed; let n = Math.floor(acc); acc -= n;
      for (let i = 0; i < n; i++) { T.tick(); if ((i & 15) === 15 && performance.now() - t0 > 14) { acc = 0; break; } }
      alpha = Math.min(1, acc);
    }
  }
  for (const e of T.events.splice(0)) {
    if (e.type === 'crash') {
      crashMarks.push({ x: e.x, y: e.y }); if (crashMarks.length > 60) crashMarks.shift();
      fx = { x: e.x, y: e.y, t: performance.now() }; if (typeof speed === 'number' && speed <= 2) { v3.flash = 0.7; v3.shake = 1; }
      banner((e.kind === 'stall' ? 'Stalled after ' : 'Crashed after ') + Math.round(e.dM) + ' m' + (e.manual ? (e.dropped ? ' · the last 0.8 s was not recorded' : '') + (T.restartAtLine ? '' : ' · carrying on from before the crash') : ''), 'crash');
    } else if (e.type === 'champ') {
      if (e.lap || e.frac >= lastChamp + 0.1) { lastChamp = e.frac; banner(e.lap ? `NEW CHAMPION: full lap ${fmtT(e.t).slice(0, 6)} without noise` : `New champion: test drive reached ${Math.round(e.frac * 100)}% of a lap`, 'lap'); }
    } else if (e.type === 'rollback') {
      banner(`Learning collapsed: rolled back to the champion (${Math.round(e.frac * 100)}%)`, 'info');
    } else if (e.type === 'env') {
      syncSliders(); banner(`Getting harder: ${T.env.dayMode === 'night' ? 'night' : 'day'}, ${T.env.weatherMode === 'rain' ? 'rain' : 'sunny'}`, 'info');
    } else banner(e.full ? `LAP COMPLETE  ${e.time.toFixed(1)} s` : 'Reached the finish line', 'lap');
  }
  refreshOverview(ov, T.tr, Math.floor(T.stats.maxReach / T.tr.spacing));
  if ($('auto').checked && T.stats.updates - lastCoach >= 40 && !$('coachbtn').disabled) { lastCoach = T.stats.updates; askCoach(); }

  { const cc = T.car; spray.update({ x: cc.x, y: cc.y, h: cc.h, v: cc.v, vang: cc.vang }, running ? dt : 0); }
  if (mapMode) drawMap(); else if (view === '3d') { if (!((speed === 'max' || speed >= 16) && frameN % 3)) draw3d(alpha, dt); } else drawWorld(alpha, dt);
  drawMini(); meters(); condTable(); demoInfo();
  if (frameN++ % 6 === 0) hud();
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
