/* Small neural networks + PPO (clipped actor-critic), written from scratch - no libraries. */
const randn = () => {
  let u = 0; while (!u) u = Math.random();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * Math.random());
};

class MLP {
  constructor(sizes, lastScale) {
    this.sizes = sizes; this.t = 0;
    const z = n => new Float64Array(n);
    this.W = []; this.b = []; this.gW = []; this.gb = []; this.mW = []; this.vW = []; this.mb = []; this.vb = [];
    for (let l = 0; l < sizes.length - 1; l++) {
      const i = sizes[l], o = sizes[l + 1], s = (l === sizes.length - 2 ? lastScale : 1) * Math.sqrt(1 / i);
      this.W.push(z(i * o).map(() => randn() * s)); this.b.push(z(o));
      this.gW.push(z(i * o)); this.gb.push(z(o));
      this.mW.push(z(i * o)); this.vW.push(z(i * o)); this.mb.push(z(o)); this.vb.push(z(o));
    }
    this.a = sizes.map(n => z(n));
  }
  forward(x) {
    const L = this.sizes.length - 1;
    this.a[0].set(x);
    for (let l = 0; l < L; l++) {
      const i = this.sizes[l], o = this.sizes[l + 1], W = this.W[l], a = this.a[l], out = this.a[l + 1];
      for (let k = 0; k < o; k++) {
        let s = this.b[l][k];
        for (let j = 0; j < i; j++) s += W[k * i + j] * a[j];
        out[k] = l < L - 1 ? Math.tanh(s) : s;
      }
    }
    return this.a[L];
  }
  // dout = gradient w.r.t. the (linear) output; accumulates into gW/gb
  backward(dout) {
    let d = Float64Array.from(dout);
    for (let l = this.sizes.length - 2; l >= 0; l--) {
      const i = this.sizes[l], o = this.sizes[l + 1], nd = new Float64Array(i), a = this.a[l], W = this.W[l], gW = this.gW[l];
      for (let k = 0; k < o; k++) {
        const g = d[k]; this.gb[l][k] += g;
        for (let j = 0; j < i; j++) { gW[k * i + j] += g * a[j]; nd[j] += g * W[k * i + j]; }
      }
      if (l > 0) for (let j = 0; j < i; j++) nd[j] *= 1 - a[j] * a[j];
      d = nd;
    }
  }
  step(lr, scale, maxNorm) {
    let n2 = 0;
    for (let l = 0; l < this.W.length; l++) {
      for (const g of this.gW[l]) n2 += (g / scale) ** 2;
      for (const g of this.gb[l]) n2 += (g / scale) ** 2;
    }
    const clip = Math.min(1, maxNorm / (Math.sqrt(n2) + 1e-8));
    this.t++;
    const c1 = 1 - 0.9 ** this.t, c2 = 1 - 0.999 ** this.t;
    const adam = (p, g, m, v) => {
      for (let k = 0; k < p.length; k++) {
        const gg = (g[k] / scale) * clip;
        m[k] = 0.9 * m[k] + 0.1 * gg; v[k] = 0.999 * v[k] + 0.001 * gg * gg;
        p[k] -= lr * (m[k] / c1) / (Math.sqrt(v[k] / c2) + 1e-8);
        g[k] = 0;
      }
    };
    for (let l = 0; l < this.W.length; l++) {
      adam(this.W[l], this.gW[l], this.mW[l], this.vW[l]);
      adam(this.b[l], this.gb[l], this.mb[l], this.vb[l]);
    }
  }
  toJSON() { return { W: this.W.map(a => Array.from(a)), b: this.b.map(a => Array.from(a)) }; }
  fromJSON(j) { j.W.forEach((a, l) => this.W[l].set(a)); j.b.forEach((a, l) => this.b[l].set(a)); }
}

class PPOAgent {
  constructor(nIn, nAct) {
    this.nAct = nAct;
    this.actor = new MLP([nIn, 32, 32, nAct], 0.05);
    this.critic = new MLP([nIn, 32, 32, 1], 1);
    this.actor.b[2][1] = 0.3;                       // gentle throttle so the untrained car creeps forward
    this.logStd = Float64Array.from([-0.7, -0.7]);   // learned exploration noise
  }

  act(o, deterministic) {
    const z = this.actor.forward(o), a = [], mu = [];
    let lp = 0;
    for (let k = 0; k < this.nAct; k++) {
      mu[k] = Math.tanh(z[k]);
      const e = deterministic ? 0 : randn();
      a[k] = mu[k] + Math.exp(this.logStd[k]) * e;
      lp += -0.5 * e * e - this.logStd[k] - 0.9189385;
    }
    const v = deterministic ? 0 : this.critic.forward(o)[0];
    return { a, lp, v };
  }
  value(o) { return this.critic.forward(o)[0]; }

  // batch: {obs, act, logp, adv, ret}; returns diagnostics
  update(B, hp) {
    const n = B.obs.length, idx = Array.from({ length: n }, (_, i) => i);
    let m = 0; for (const a of B.adv) m += a; m /= n;
    let s = 0; for (const a of B.adv) s += (a - m) ** 2; s = Math.sqrt(s / n) + 1e-8;
    const adv = B.adv.map(a => (a - m) / s);
    let kl = 0, vloss = 0, cnt = 0;
    for (let ep = 0; ep < hp.epochs; ep++) {
      for (let i = n - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [idx[i], idx[j]] = [idx[j], idx[i]]; }
      let epKl = 0, epN = 0;
      for (let st = 0; st < n; st += hp.mb) {
        const mbIdx = idx.slice(st, st + hp.mb), dls = [0, 0];
        for (const i of mbIdx) {
          const o = B.obs[i], z = this.actor.forward(o), dz = new Float64Array(this.nAct);
          let lp = 0; const mu = [], std = [];
          for (let k = 0; k < this.nAct; k++) {
            mu[k] = Math.tanh(z[k]); std[k] = Math.exp(this.logStd[k]);
            lp += -0.5 * ((B.act[i][k] - mu[k]) / std[k]) ** 2 - this.logStd[k] - 0.9189385;
          }
          const ratio = Math.exp(Math.max(-10, Math.min(10, lp - B.logp[i]))), A = adv[i];
          const active = (A >= 0 && ratio < 1 + hp.clip) || (A < 0 && ratio > 1 - hp.clip);
          const dLogp = active ? -A * ratio : 0;
          for (let k = 0; k < this.nAct; k++) {
            const diff = B.act[i][k] - mu[k];
            dz[k] = dLogp * (diff / (std[k] * std[k])) * (1 - mu[k] * mu[k]);
            dls[k] += dLogp * ((diff * diff) / (std[k] * std[k]) - 1) - hp.entropy;
          }
          if (!hp.freeze) this.actor.backward(dz);
          const v = this.critic.forward(o)[0], err = Math.max(-10, Math.min(10, v - B.ret[i]));
          this.critic.backward([err]);
          vloss += 0.5 * err * err; cnt++;
          epKl += B.logp[i] - lp; epN++;
        }
        if (!hp.freeze) this.actor.step(hp.lr, mbIdx.length, 0.5);
        this.critic.step(hp.lr * 3, mbIdx.length, 1.0);
        if (!hp.freeze) for (let k = 0; k < this.nAct; k++)
          this.logStd[k] = Math.max(-3, Math.min(0.2, this.logStd[k] - hp.lr * 10 * dls[k] / mbIdx.length));
      }
      kl = epKl / epN;
      if (kl > 0.04) break;           // policy moved enough - stop early
    }
    return { kl, vloss: vloss / cnt, std: Array.from(this.logStd).map(Math.exp) };
  }

  toJSON() { return { actor: this.actor.toJSON(), critic: this.critic.toJSON(), logStd: Array.from(this.logStd) }; }
  fromJSON(j) { this.actor.fromJSON(j.actor); this.critic.fromJSON(j.critic); this.logStd.set(j.logStd); }
}
